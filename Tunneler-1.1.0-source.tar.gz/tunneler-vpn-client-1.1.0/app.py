#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
import tkinter as tk
from pathlib import Path

from tunny import APP_NAME, __version__
from tunny.command import CommandRunner
from tunny.controller import TunnyController
from tunny.logging_setup import configure_logging
from tunny.privileged import main as privileged_main
from tunny.ui import TunnyApp


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Tunneler Linux VPN connection assistant")
    parser.add_argument("--verbose", action="store_true", help="write extra detail to the redacted log")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "--privileged-helper":
        return privileged_main(argv[1:])
    args = parse_args(argv)
    log_path = configure_logging(args.verbose)
    app_path = Path(__file__).resolve()
    root = tk.Tk()
    ui_holder: dict[str, TunnyApp] = {}

    def on_log(line: str) -> None:
        ui = ui_holder.get("app")
        if ui:
            ui.queue_log(line)

    runner = CommandRunner(on_log=on_log)
    controller = TunnyController(runner, app_path)
    ui = TunnyApp(root, controller, log_path)
    ui_holder["app"] = ui
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
