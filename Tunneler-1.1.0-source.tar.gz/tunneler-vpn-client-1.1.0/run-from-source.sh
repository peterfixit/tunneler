#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is required." >&2
  exit 1
fi

if ! python3 -c 'import tkinter' >/dev/null 2>&1; then
  echo "ERROR: Python Tk support is missing. Run ./packaging/install-build-deps.sh first." >&2
  exit 1
fi

exec python3 "$ROOT_DIR/app.py" "$@"

