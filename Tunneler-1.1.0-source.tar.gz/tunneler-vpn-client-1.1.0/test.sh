#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

python3 -m compileall -q app.py tunny tests
python3 -m unittest discover -s tests -v

for script in run-from-source.sh test.sh packaging/*.sh; do
  bash -n "$script"
done

echo "All Tunneler checks passed."
