from __future__ import annotations

import os
import subprocess
import unittest
from unittest import mock

from tunny.command import CommandRunner, Redactor
from tunny.models import Credentials, Protocol
from tunny.secrets import password_file


class CommandAndSecretTests(unittest.TestCase):
    def test_redactor(self) -> None:
        text = "password=hunter2 private-key=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
        redacted = Redactor.text(text)
        self.assertNotIn("hunter2", redacted)
        self.assertNotIn("AAAAAAAA", redacted)

    def test_runner_does_not_use_shell(self) -> None:
        result = CommandRunner().run(["printf", "%s", "$(touch /tmp/tunny-nope)"], timeout=3)
        self.assertTrue(result.ok)
        self.assertEqual(result.stdout, "$(touch /tmp/tunny-nope)")
        self.assertFalse(os.path.exists("/tmp/tunny-nope"))

    def test_password_file_mode_and_cleanup(self) -> None:
        credentials = Credentials(password="test password", ipsec_psk="test psk")
        retained = ""
        with password_file(Protocol.L2TP, credentials) as path:
            self.assertIsNotNone(path)
            retained = path or ""
            self.assertEqual(os.stat(retained).st_mode & 0o777, 0o600)
            with open(retained, encoding="utf-8") as handle:
                text = handle.read()
            self.assertIn("vpn.secrets.password:test password", text)
            self.assertIn("vpn.secrets.ipsec-psk:test psk", text)
        self.assertFalse(os.path.exists(retained))

    def test_newline_secret_rejected(self) -> None:
        with self.assertRaises(ValueError):
            with password_file(Protocol.OPENVPN, Credentials(password="bad\nsecret")):
                pass

    def test_timeout_with_byte_output_is_reported(self) -> None:
        expired = subprocess.TimeoutExpired(
            ["nmcli"], 1, output=b"partial output", stderr=b"waiting"
        )
        with mock.patch("tunny.command.subprocess.run", side_effect=expired):
            result = CommandRunner().run(["nmcli"], timeout=1)
        self.assertTrue(result.timed_out)
        self.assertEqual(result.stdout, "partial output")
        self.assertIn("Timed out after 1s", result.stderr)


if __name__ == "__main__":
    unittest.main()
