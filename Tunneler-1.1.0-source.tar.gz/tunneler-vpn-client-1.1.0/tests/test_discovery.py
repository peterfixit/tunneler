from __future__ import annotations

import unittest

from tunny.discovery import DiscoveryEngine
from tunny.models import DiscoveryResult, Protocol


class DiscoveryTests(unittest.TestCase):
    def test_deduplicate_keeps_higher_confidence(self) -> None:
        possible = DiscoveryResult(
            Protocol.OPENCONNECT, "vpn.example.com", 443, "probe", "possible"
        )
        likely = DiscoveryResult(
            Protocol.OPENCONNECT, "vpn.example.com", 443, "DNS", "likely"
        )
        result = DiscoveryEngine._deduplicate([possible, likely])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].confidence, "likely")


if __name__ == "__main__":
    unittest.main()

