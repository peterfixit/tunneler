from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tunny.distro import detect_distribution, package_command, packages_for
from tunny.models import Protocol


class DistroTests(unittest.TestCase):
    def _detect(self, content: str):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "os-release"
            path.write_text(content, encoding="utf-8")
            return detect_distribution(path)

    def test_cachyos_is_arch(self) -> None:
        distro = self._detect('ID=cachyos\nID_LIKE="arch"\nPRETTY_NAME="CachyOS"\n')
        self.assertEqual(distro.family, "arch")
        self.assertEqual(distro.package_manager, "pacman")

    def test_nobara_is_fedora(self) -> None:
        distro = self._detect('ID=nobara\nID_LIKE="fedora"\n')
        self.assertEqual(distro.family, "fedora")

    def test_arch_l2tp_packages(self) -> None:
        distro = self._detect('ID=arch\n')
        packages = packages_for(distro, Protocol.L2TP)
        self.assertIn("networkmanager-l2tp", packages)
        command = package_command(distro, packages)[0]
        self.assertEqual(command[:4], ["pacman", "-S", "--needed", "--noconfirm"])

    def test_debian_runs_update_then_install(self) -> None:
        distro = self._detect('ID=ubuntu\nID_LIKE="debian"\n')
        commands = package_command(distro, packages_for(distro, Protocol.WIREGUARD))
        self.assertEqual(commands[0], ["apt-get", "update"])
        self.assertEqual(commands[1][0:2], ["apt-get", "install"])


if __name__ == "__main__":
    unittest.main()

