from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tunny.filepicker import (
    FileType,
    _native_command,
    _run_native_picker,
    native_picker_backend,
)


FILETYPES = (
    FileType("VPN configurations", ("*.conf", "*.ovpn")),
    FileType("All files", ("*",)),
)


class FilePickerTests(unittest.TestCase):
    def test_prefers_kdialog_on_plasma(self) -> None:
        available = {"kdialog": "/usr/bin/kdialog", "zenity": "/usr/bin/zenity"}
        backend = native_picker_backend(
            {"XDG_CURRENT_DESKTOP": "KDE"}, which=available.get
        )
        self.assertEqual(backend, "kdialog")

    def test_prefers_zenity_on_gnome(self) -> None:
        available = {"kdialog": "/usr/bin/kdialog", "zenity": "/usr/bin/zenity"}
        backend = native_picker_backend(
            {"XDG_CURRENT_DESKTOP": "GNOME"}, which=available.get
        )
        self.assertEqual(backend, "zenity")

    def test_included_picker_needs_no_external_command(self) -> None:
        self.assertEqual(native_picker_backend({}, which=lambda _name: None), "")

    def test_kdialog_command_keeps_values_as_arguments(self) -> None:
        command = _native_command(
            "kdialog", "Choose VPN configuration", Path("/tmp"), FILETYPES
        )
        self.assertEqual(command[0], "kdialog")
        self.assertIn("*.conf *.ovpn|VPN configurations", command[-1])
        self.assertNotIn("sh", command[:1])

    def test_native_cancel_does_not_open_fallback(self) -> None:
        completed = subprocess.CompletedProcess(["kdialog"], 1, stdout="", stderr="")
        with mock.patch("tunny.filepicker.subprocess.run", return_value=completed):
            handled, selected = _run_native_picker(
                "kdialog", "Choose", Path("/tmp"), FILETYPES
            )
        self.assertTrue(handled)
        self.assertEqual(selected, "")

    def test_native_failure_allows_included_fallback(self) -> None:
        with mock.patch(
            "tunny.filepicker.subprocess.run", side_effect=FileNotFoundError("missing")
        ):
            handled, selected = _run_native_picker(
                "kdialog", "Choose", Path("/tmp"), FILETYPES
            )
        self.assertFalse(handled)
        self.assertEqual(selected, "")

    def test_native_selection_is_returned(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            selected = str(Path(directory) / "client.conf")
            completed = subprocess.CompletedProcess(
                ["zenity"], 0, stdout=selected + "\n", stderr=""
            )
            with mock.patch("tunny.filepicker.subprocess.run", return_value=completed):
                handled, result = _run_native_picker(
                    "zenity", "Choose", Path(directory), FILETYPES
                )
            self.assertTrue(handled)
            self.assertEqual(result, selected)


if __name__ == "__main__":
    unittest.main()
