from __future__ import annotations

import os
import base64
import tempfile
import unittest
from pathlib import Path

from tunny.importer import inspect_config, stage_config
from tunny.models import Protocol
from tunny.validation import ValidationError


VALID_KEY = base64.b64encode(bytes(range(32))).decode()


class ImporterTests(unittest.TestCase):
    def test_wireguard_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "example.conf"
            path.write_text(
                f"[Interface]\nPrivateKey = {VALID_KEY}\nAddress = 10.20.0.2/24\nDNS = 10.20.0.1\n"
                f"[Peer]\nPublicKey = {VALID_KEY}\nAllowedIPs = 10.30.0.0/24\n"
                "Endpoint = vpn.example.com:51820\n",
                encoding="utf-8",
            )
            result = inspect_config(path)
            self.assertEqual(result.protocol, Protocol.WIREGUARD)
            self.assertEqual(result.endpoint, "vpn.example.com")
            self.assertEqual(result.allowed_ips, ["10.30.0.0/24"])

    def test_wireguard_hooks_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.conf"
            path.write_text(
                f"[Interface]\nPrivateKey={VALID_KEY}\nPostUp = touch /tmp/bad\n"
                f"[Peer]\nPublicKey={VALID_KEY}\nAllowedIPs=10.20.0.0/24\n",
                encoding="utf-8",
            )
            with self.assertRaises(ValidationError):
                inspect_config(path)

    def test_openvpn_scripts_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.ovpn"
            path.write_text("client\nremote vpn.example.com\nup /tmp/script\n", encoding="utf-8")
            with self.assertRaises(ValidationError):
                inspect_config(path)

    def test_openvpn_cert_is_staged_privately(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source"
            target = Path(directory) / "target"
            source.mkdir()
            cert = source / "client.crt"
            cert.write_text("example cert", encoding="utf-8")
            config = source / "client.ovpn"
            config.write_text(
                "client\nremote vpn.example.com 1194\ncert client.crt\n", encoding="utf-8"
            )
            inspected = inspect_config(config)
            staged = stage_config(inspected, target)
            self.assertTrue(staged.exists())
            self.assertTrue((staged.parent / "client.crt").exists())
            self.assertEqual(os.stat(staged).st_mode & 0o777, 0o600)
            self.assertIn(str(staged.parent / "client.crt"), staged.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
