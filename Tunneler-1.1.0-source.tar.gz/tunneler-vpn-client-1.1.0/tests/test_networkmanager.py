from __future__ import annotations

import unittest
import base64
import uuid
from unittest import mock

from tunny.networkmanager import NetworkManager, _protocol_from_service, parse_terse_line
from tunny.models import CommandResult, Protocol, WireGuardConfig, WireGuardPeer


class FailingRunner:
    def run(self, _args, **_kwargs) -> CommandResult:
        return CommandResult([], 10, "", "NetworkManager is not running")


class NetworkManagerParsingTests(unittest.TestCase):
    def test_escaped_colon(self) -> None:
        self.assertEqual(
            parse_terse_line(r"Office\: VPN:1234:vpn"),
            ["Office: VPN", "1234", "vpn"],
        )

    def test_wireguard_type(self) -> None:
        self.assertEqual(_protocol_from_service("wireguard", ""), Protocol.WIREGUARD)

    def test_vpn_services(self) -> None:
        self.assertEqual(
            _protocol_from_service("vpn", "org.freedesktop.NetworkManager.openvpn"),
            Protocol.OPENVPN,
        )
        self.assertEqual(
            _protocol_from_service("vpn", "org.freedesktop.NetworkManager.strongswan"),
            Protocol.IKEV2,
        )

    def test_wireguard_keyfile_does_not_use_command_arguments_for_private_key(self) -> None:
        key = base64.b64encode(bytes(range(32))).decode()
        profile_uuid = str(uuid.uuid4())
        content = NetworkManager._wireguard_keyfile(
            "Example VPN",
            profile_uuid,
            WireGuardConfig(
                private_key=key,
                addresses=["10.20.0.2/24"],
                peers=[
                    WireGuardPeer(
                        public_key=key,
                        allowed_ips=["10.30.0.0/24"],
                        endpoint="vpn.example.com",
                        port=51820,
                    )
                ],
            ),
            False,
        )
        self.assertIn("type=wireguard", content)
        self.assertIn(f"private-key={key}", content)
        self.assertIn("allowed-ips=10.30.0.0/24;", content)
        self.assertIn("never-default=true", content)

    def test_profile_list_failure_is_not_mistaken_for_an_empty_list(self) -> None:
        manager = NetworkManager(FailingRunner())
        with mock.patch("tunny.networkmanager.shutil.which", return_value="/usr/bin/nmcli"):
            with self.assertRaisesRegex(RuntimeError, "could not list VPN profiles"):
                manager.list_profiles()


if __name__ == "__main__":
    unittest.main()
