from __future__ import annotations

import base64
import os
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest import mock

from tunny.models import WireGuardConfig, WireGuardPeer
from tunny.networkmanager import NetworkManager
from tunny.privileged import _validated_keyfile


class PrivilegedKeyfileTests(unittest.TestCase):
    def _write_keyfile(self, content: str, path: Path) -> None:
        path.write_text(content, encoding="utf-8")
        path.chmod(0o600)

    def test_generated_keyfile_passes_privileged_validation(self) -> None:
        key = base64.b64encode(bytes(range(32))).decode()
        profile_uuid = str(uuid.uuid4())
        content = NetworkManager._wireguard_keyfile(
            "Example",
            profile_uuid,
            WireGuardConfig(
                private_key=key,
                addresses=["10.20.0.2/24"],
                peers=[WireGuardPeer(key, ["10.30.0.0/24"], "vpn.example.com", 51820)],
            ),
            False,
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "profile.nmconnection"
            self._write_keyfile(content, path)
            with mock.patch.dict(os.environ, {"PKEXEC_UID": str(os.getuid())}):
                data, parsed_uuid = _validated_keyfile(str(path))
            self.assertEqual(parsed_uuid, profile_uuid)
            self.assertEqual(data.decode(), content)

    def test_world_readable_keyfile_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.nmconnection"
            path.write_text("[connection]\n", encoding="utf-8")
            path.chmod(0o644)
            with mock.patch.dict(os.environ, {"PKEXEC_UID": str(os.getuid())}):
                with self.assertRaises(RuntimeError):
                    _validated_keyfile(str(path))


if __name__ == "__main__":
    unittest.main()

