from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from tunny.models import ProfileRecord, Protocol
from tunny.settings import Settings, SettingsStore


class SettingsTests(unittest.TestCase):
    def test_round_trip_and_private_mode(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config" / "settings.json"
            store = SettingsStore(path)
            settings = Settings(
                profiles=[ProfileRecord("Example", "uuid-1", Protocol.WIREGUARD)],
                last_picker_directory="/tmp/example",
            )
            store.save(settings)
            loaded = store.load()
            self.assertEqual(loaded.profiles[0].protocol, Protocol.WIREGUARD)
            self.assertEqual(loaded.theme, "dark")
            self.assertEqual(loaded.last_picker_directory, "/tmp/example")
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)

    def test_loads_legacy_tunny_settings_without_deleting_them(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            current = root / "tunneler" / "settings.json"
            legacy = root / "tunny" / "settings.json"
            legacy.parent.mkdir(parents=True)
            legacy.write_text('{"last_profile_uuid": "legacy-uuid"}', encoding="utf-8")
            loaded = SettingsStore(current, legacy_path=legacy).load()
            self.assertEqual(loaded.last_profile_uuid, "legacy-uuid")
            self.assertTrue(legacy.exists())

    def test_broken_json_is_quarantined(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            path.write_text("not json", encoding="utf-8")
            loaded = SettingsStore(path).load()
            self.assertEqual(loaded.profiles, [])
            self.assertTrue(path.with_suffix(".json.broken").exists())


if __name__ == "__main__":
    unittest.main()
