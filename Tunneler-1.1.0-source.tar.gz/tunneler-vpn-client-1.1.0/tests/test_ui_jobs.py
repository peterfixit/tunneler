from __future__ import annotations

import queue
import unittest

from tunny.ui import TunnyApp


class FakeRoot:
    def after(self, _delay: int, _callback) -> None:
        pass


class UiJobTests(unittest.TestCase):
    def make_app(self) -> TunnyApp:
        app = TunnyApp.__new__(TunnyApp)
        app.root = FakeRoot()
        app.busy = False
        app.job_queue = queue.Queue()
        app.job_number = 0
        app.active_job = None
        app.job_deadline = None
        app.active_job_quiet = False
        app.closing = False
        app._set_status = lambda _text, _state: None
        return app

    def drain_after_worker(self, app: TunnyApp) -> None:
        result = app.job_queue.get(timeout=2)
        app.job_queue.put(result)
        app._drain_job_queue()

    def test_background_failure_clears_busy_state(self) -> None:
        app = self.make_app()
        errors: list[str] = []
        app._render_profile_error = errors.append

        def fail() -> None:
            raise RuntimeError("example failure")

        app._run_job("Refresh", fail, lambda _value: None, quiet=True)
        self.drain_after_worker(app)

        self.assertFalse(app.busy)
        self.assertIsNone(app.active_job)
        self.assertEqual(errors, ["example failure"])

    def test_background_success_runs_completion_on_drain(self) -> None:
        app = self.make_app()
        completed: list[str] = []
        app._run_job("Refresh", lambda: "ready", completed.append)
        self.drain_after_worker(app)

        self.assertFalse(app.busy)
        self.assertEqual(completed, ["ready"])


if __name__ == "__main__":
    unittest.main()
