from __future__ import annotations

import base64
import unittest

from tunny.models import ProfileDraft, Protocol
from tunny.validation import (
    ValidationError,
    networks_overlap,
    split_endpoint,
    validate_draft,
    validate_networks,
    validate_wireguard_key,
)


VALID_KEY = base64.b64encode(bytes(range(32))).decode()


class ValidationTests(unittest.TestCase):
    def test_endpoint_hostname_and_port(self) -> None:
        self.assertEqual(split_endpoint("vpn.example.com:51820"), ("vpn.example.com", 51820))

    def test_endpoint_ipv6_and_port(self) -> None:
        self.assertEqual(split_endpoint("[2001:db8::1]:443"), ("2001:db8::1", 443))

    def test_url_endpoint(self) -> None:
        self.assertEqual(split_endpoint("https://vpn.example.com:4443/path"), ("vpn.example.com", 4443))

    def test_bad_port_rejected(self) -> None:
        with self.assertRaises(ValidationError):
            split_endpoint("vpn.example.com:70000")

    def test_wireguard_key_length(self) -> None:
        self.assertEqual(validate_wireguard_key(VALID_KEY, "Key"), VALID_KEY)
        with self.assertRaises(ValidationError):
            validate_wireguard_key(base64.b64encode(b"short").decode(), "Key")

    def test_networks_are_normalized(self) -> None:
        self.assertEqual(validate_networks(["10.20.0.3/24"]), ["10.20.0.0/24"])

    def test_overlap(self) -> None:
        self.assertEqual(
            networks_overlap(["192.0.2.0/24"], ["192.0.2.128/25"]),
            [("192.0.2.0/24", "192.0.2.128/25")],
        )

    def test_wireguard_draft(self) -> None:
        draft = ProfileDraft(
            name="Example VPN",
            protocol=Protocol.WIREGUARD,
            endpoint="vpn.example.com",
            port=51820,
            private_key=VALID_KEY,
            public_key=VALID_KEY,
            interface_addresses=["10.20.0.2/24"],
            allowed_ips=["10.30.0.0/24"],
            dns_servers=["10.20.0.1"],
        )
        result = validate_draft(draft)
        self.assertEqual(result.endpoint, "vpn.example.com")
        self.assertEqual(result.interface_addresses, ["10.20.0.2/24"])

    def test_wireguard_full_tunnel_adds_default_allowed_ip(self) -> None:
        draft = ProfileDraft(
            name="Full tunnel",
            protocol=Protocol.WIREGUARD,
            endpoint="vpn.example.com",
            private_key=VALID_KEY,
            public_key=VALID_KEY,
            interface_addresses=["10.20.0.2/24"],
            allowed_ips=["10.30.0.0/24"],
            full_tunnel=True,
        )
        result = validate_draft(draft)
        self.assertIn("0.0.0.0/0", result.allowed_ips)

    def test_vpn_data_injection_characters_rejected(self) -> None:
        draft = ProfileDraft(
            name="Bad",
            protocol=Protocol.L2TP,
            endpoint="vpn.example.com",
            username="user,ipsec-enabled=no",
        )
        with self.assertRaises(ValidationError):
            validate_draft(draft)


if __name__ == "__main__":
    unittest.main()
