"""Tunneler VPN Client."""

__version__ = "1.1.0"
APP_NAME = "Tunneler"
APP_ID = "au.pmhs.tunneler"
