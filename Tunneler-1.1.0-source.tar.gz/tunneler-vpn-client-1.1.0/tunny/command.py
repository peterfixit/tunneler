from __future__ import annotations

import logging
import os
import re
import subprocess
import time
from collections.abc import Callable, Iterable

from .models import CommandResult


LOGGER = logging.getLogger("tunny.command")
DEFAULT_ENV = {
    "LC_ALL": "C",
    "LANG": "C",
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
}


def _as_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


class Redactor:
    _patterns = [
        re.compile(r"(?i)(private[-_ ]?key\s*[:=]\s*)\S+"),
        re.compile(r"(?i)(preshared[-_ ]?key\s*[:=]\s*)\S+"),
        re.compile(r"(?i)(password\s*[:=]\s*)\S+"),
        re.compile(r"(?i)(ipsec[-_ ]?psk\s*[:=]\s*)\S+"),
        re.compile(r"(?i)(vpn\.secrets\.[^:=\s]+\s*[:=]\s*)\S+"),
        re.compile(r"(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{43}=(?![A-Za-z0-9+/=])"),
    ]

    @classmethod
    def text(cls, value: str) -> str:
        result = value
        for pattern in cls._patterns:
            if pattern.groups:
                result = pattern.sub(r"\1[REDACTED]", result)
            else:
                result = pattern.sub("[REDACTED]", result)
        return result

    @classmethod
    def args(cls, args: Iterable[str]) -> list[str]:
        return [cls.text(str(item)) for item in args]


class CommandRunner:
    def __init__(self, on_log: Callable[[str], None] | None = None) -> None:
        self.on_log = on_log

    def _log(self, message: str) -> None:
        safe = Redactor.text(message)
        LOGGER.info(safe)
        if self.on_log:
            self.on_log(safe)

    def run(
        self,
        args: list[str],
        *,
        timeout: float = 30,
        input_text: str | None = None,
        check: bool = False,
        env: dict[str, str] | None = None,
    ) -> CommandResult:
        if not args or any(not isinstance(item, str) for item in args):
            raise ValueError("Command must be a non-empty list of strings")
        command_env = os.environ.copy()
        command_env.update(DEFAULT_ENV)
        if env:
            command_env.update(env)
        safe_args = Redactor.args(args)
        self._log("Running: " + " ".join(safe_args))
        started = time.monotonic()
        try:
            proc = subprocess.run(
                args,
                input=input_text,
                text=True,
                capture_output=True,
                timeout=timeout,
                env=command_env,
                shell=False,
                check=False,
            )
            result = CommandResult(
                args=safe_args,
                returncode=proc.returncode,
                stdout=Redactor.text(proc.stdout),
                stderr=Redactor.text(proc.stderr),
                duration_seconds=time.monotonic() - started,
            )
        except subprocess.TimeoutExpired as exc:
            result = CommandResult(
                args=safe_args,
                returncode=124,
                stdout=Redactor.text(_as_text(exc.stdout)),
                stderr=Redactor.text(_as_text(exc.stderr)) + f"\nTimed out after {timeout:g}s",
                timed_out=True,
                duration_seconds=time.monotonic() - started,
            )
        except FileNotFoundError as exc:
            result = CommandResult(
                args=safe_args,
                returncode=127,
                stdout="",
                stderr=str(exc),
                duration_seconds=time.monotonic() - started,
            )
        self._log(
            f"Command finished rc={result.returncode} in {result.duration_seconds:.2f}s"
        )
        if check and not result.ok:
            detail = result.stderr.strip() or result.stdout.strip() or "Unknown command error"
            raise RuntimeError(f"Command failed: {detail}")
        return result


def output_excerpt(result: CommandResult, limit: int = 800) -> str:
    text = (result.stderr.strip() or result.stdout.strip() or "No details were returned.")
    if len(text) > limit:
        return text[: limit - 1] + "…"
    return text
