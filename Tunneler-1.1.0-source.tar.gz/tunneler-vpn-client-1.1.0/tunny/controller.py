from __future__ import annotations

import shutil
import sys
import glob
from pathlib import Path

from .command import CommandRunner, output_excerpt
from .diagnostics import DiagnosticEngine
from .discovery import DiscoveryEngine
from .distro import detect_distribution, missing_tools, packages_for
from .models import ConnectionOutcome, Credentials, ProfileDraft, ProfileRecord, Protocol
from .networkmanager import NetworkManager
from .repair import RepairEngine
from .secrets import DesktopKeyring
from .settings import SettingsStore


class TunnyController:
    def __init__(self, runner: CommandRunner, app_path: Path) -> None:
        self.runner = runner
        self.app_path = app_path
        self.store = SettingsStore()
        self.settings = self.store.load()
        self.nm = NetworkManager(runner, keyfile_installer=self.install_keyfile)
        self.diagnostics = DiagnosticEngine(runner, self.nm)
        self.repairs = RepairEngine(self.nm)
        self.discovery = DiscoveryEngine(runner)
        self.keyring = DesktopKeyring(runner)

    def list_profiles(self) -> list[ProfileRecord]:
        if not self.nm.available:
            return sorted(self.settings.profiles, key=lambda item: item.name.casefold())
        if self.nm.state() == "unavailable":
            return sorted(self.settings.profiles, key=lambda item: item.name.casefold())
        system = self.nm.list_profiles()
        metadata = {item.uuid: item for item in self.settings.profiles}
        merged: list[ProfileRecord] = []
        for item in system:
            merged.append(metadata.get(item.uuid, item))
        existing = {item.uuid for item in system}
        if any(item.uuid not in existing for item in self.settings.profiles):
            self.settings.profiles = [item for item in self.settings.profiles if item.uuid in existing]
            self.store.save(self.settings)
        return sorted(merged, key=lambda item: item.name.casefold())

    def add_manual(self, draft: ProfileDraft) -> ProfileRecord:
        profile = self.nm.create_profile(draft)
        self._save_profile(profile)
        return profile

    def add_imported(self, file_path: str, name: str) -> tuple[ProfileRecord, list[str]]:
        profile, inspected = self.nm.import_profile(file_path, name)
        self._save_profile(profile)
        return profile, inspected.warnings

    def _save_profile(self, profile: ProfileRecord) -> None:
        self.settings.profiles = [item for item in self.settings.profiles if item.uuid != profile.uuid]
        self.settings.profiles.append(profile)
        self.settings.last_profile_uuid = profile.uuid
        self.store.save(self.settings)

    def delete_profile(self, profile: ProfileRecord) -> tuple[bool, str]:
        if not self.nm.delete(profile.uuid):
            return False, "NetworkManager could not delete the profile."
        self.keyring.clear_profile(profile.uuid)
        self.settings.profiles = [item for item in self.settings.profiles if item.uuid != profile.uuid]
        if self.settings.last_profile_uuid == profile.uuid:
            self.settings.last_profile_uuid = ""
        self.store.save(self.settings)
        return True, "VPN profile deleted."

    def connect_and_test(
        self,
        profile: ProfileRecord,
        credentials: Credentials,
        *,
        remember: bool = False,
    ) -> ConnectionOutcome:
        if self.nm.available and self.nm.state() == "unavailable":
            started, start_message = self.start_networkmanager()
            if not started:
                return ConnectionOutcome(
                    connected=False,
                    message=f"NetworkManager could not be started: {start_message}",
                    checks=self.diagnostics.run(profile),
                )
        connected, message = self.nm.connect(profile, credentials)
        checks = self.diagnostics.run(profile)
        repaired: list[str] = []
        if self.settings.auto_repair:
            repaired = self.repairs.apply_safe(profile, credentials, checks)
            if repaired:
                checks = self.diagnostics.run(profile)
                connected = profile.uuid in self.nm.active_uuids()
        if connected and remember and self.keyring.available:
            if credentials.password:
                self.keyring.store(profile.uuid, "password", credentials.password)
            if credentials.ipsec_psk:
                self.keyring.store(profile.uuid, "ipsec-psk", credentials.ipsec_psk)
            if credentials.cert_password:
                self.keyring.store(profile.uuid, "cert-password", credentials.cert_password)
        self.settings.last_profile_uuid = profile.uuid
        self.store.save(self.settings)
        return ConnectionOutcome(connected=connected, message=message, checks=checks, repaired=repaired)

    def saved_credentials(self, profile: ProfileRecord) -> Credentials:
        if not self.keyring.available:
            return Credentials()
        return Credentials(
            password=self.keyring.lookup(profile.uuid, "password"),
            ipsec_psk=self.keyring.lookup(profile.uuid, "ipsec-psk"),
            cert_password=self.keyring.lookup(profile.uuid, "cert-password"),
        )

    def install_support(self, protocol: Protocol) -> tuple[bool, str]:
        distro = detect_distribution()
        try:
            packages = packages_for(distro, protocol)
        except RuntimeError as exc:
            return False, str(exc)
        if shutil.which("pkexec") is None:
            return False, "pkexec is not installed; install polkit and try again."
        if getattr(sys, "frozen", False):
            launcher = [sys.executable, "--privileged-helper"]
        else:
            launcher = [sys.executable, str(self.app_path), "--privileged-helper"]
        result = self.runner.run(
            ["pkexec", *launcher, "install", protocol.value], timeout=1200
        )
        if result.ok:
            return True, f"Installed VPN support: {', '.join(packages)}"
        return False, output_excerpt(result, 1600)

    def install_keyfile(self, path: str) -> tuple[bool, str]:
        if shutil.which("pkexec") is None:
            return False, "pkexec is not installed; install polkit and try again."
        if getattr(sys, "frozen", False):
            launcher = [sys.executable, "--privileged-helper"]
        else:
            launcher = [sys.executable, str(self.app_path), "--privileged-helper"]
        result = self.runner.run(
            ["pkexec", *launcher, "install-keyfile", path], timeout=90
        )
        return result.ok, result.stdout.strip() if result.ok else output_excerpt(result, 1600)

    def start_networkmanager(self) -> tuple[bool, str]:
        if shutil.which("pkexec") is None:
            return False, "pkexec is not installed."
        if getattr(sys, "frozen", False):
            launcher = [sys.executable, "--privileged-helper"]
        else:
            launcher = [sys.executable, str(self.app_path), "--privileged-helper"]
        result = self.runner.run(
            ["pkexec", *launcher, "start-networkmanager"], timeout=90
        )
        return result.ok, result.stdout.strip() if result.ok else output_excerpt(result)

    def support_status(self, protocol: Protocol) -> tuple[bool, str]:
        missing = missing_tools(protocol)
        if not self.nm.available:
            missing.insert(0, "nmcli")
        plugin_needles = {
            Protocol.OPENVPN: "openvpn",
            Protocol.L2TP: "l2tp",
            Protocol.IKEV2: "strongswan",
            Protocol.OPENCONNECT: "openconnect",
        }
        needle = plugin_needles.get(protocol)
        if needle:
            plugin_files = glob.glob("/usr/lib*/NetworkManager/VPN/*") + glob.glob(
                "/usr/libexec/NetworkManager/VPN/*"
            )
            if not any(needle in Path(item).name.lower() for item in plugin_files):
                missing.append(f"NetworkManager {needle} plugin")
        if missing:
            return False, "Missing: " + ", ".join(dict.fromkeys(missing))
        return True, "Required command-line tools are available."
