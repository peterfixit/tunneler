from __future__ import annotations

import ipaddress
import re
import shutil
import socket
import time

from .command import CommandRunner
from .models import CheckResult, CheckStatus, ProfileRecord, Protocol
from .networkmanager import NetworkManager
from .validation import networks_overlap, split_endpoint


def _check(code: str, title: str, status: CheckStatus, detail: str, repair: str = "") -> CheckResult:
    return CheckResult(code=code, title=title, status=status, detail=detail, repair_id=repair)


class DiagnosticEngine:
    def __init__(self, runner: CommandRunner, network_manager: NetworkManager) -> None:
        self.runner = runner
        self.nm = network_manager

    def run(self, profile: ProfileRecord) -> list[CheckResult]:
        checks: list[CheckResult] = []
        if not self.nm.available:
            return [
                _check(
                    "nm_missing", "NetworkManager tools", CheckStatus.FAIL,
                    "nmcli is not installed. Install the selected VPN support first.",
                    "install-dependencies",
                )
            ]
        state = self.nm.state()
        if state.startswith("connected") or state == "connecting":
            checks.append(_check("nm_state", "NetworkManager", CheckStatus.PASS, f"State: {state}"))
        else:
            checks.append(
                _check(
                    "nm_inactive", "NetworkManager", CheckStatus.FAIL,
                    f"NetworkManager state is '{state}'.", "start-networkmanager",
                )
            )
        if self.nm.profile_exists(profile.uuid):
            checks.append(_check("profile", "VPN profile", CheckStatus.PASS, "Profile is installed."))
        else:
            checks.append(
                _check(
                    "profile_missing", "VPN profile", CheckStatus.FAIL,
                    "The profile no longer exists in NetworkManager. Import or create it again.",
                )
            )
            return checks

        active = profile.uuid in self.nm.active_uuids()
        checks.append(
            _check(
                "active" if active else "inactive",
                "Tunnel state",
                CheckStatus.PASS if active else CheckStatus.FAIL,
                "The VPN tunnel is active." if active else "The VPN tunnel is not active.",
                "reconnect" if not active else "",
            )
        )

        endpoint_ip = self._resolve_endpoint(profile, checks)
        if endpoint_ip:
            self._check_endpoint_route(endpoint_ip, checks)
        self._check_overlap(profile, checks)
        if active:
            self._check_expected_route(profile, checks)
            self._check_dns(profile, checks)
            self._check_reachability(profile, checks)
            if profile.protocol == Protocol.WIREGUARD:
                self._check_wireguard(profile, checks)
        checks.extend(self._classify_recent_logs(profile))
        return checks

    def _resolve_endpoint(self, profile: ProfileRecord, checks: list[CheckResult]) -> str:
        if not profile.endpoint:
            checks.append(
                _check(
                    "endpoint_unknown", "Server address", CheckStatus.INFO,
                    "The server address is managed inside the imported profile.",
                )
            )
            return ""
        try:
            host, _ = split_endpoint(profile.endpoint)
            addresses = socket.getaddrinfo(host, None, type=socket.SOCK_DGRAM)
            address = addresses[0][4][0]
            checks.append(
                _check("endpoint_dns", "Server resolution", CheckStatus.PASS, f"{host} resolves to {address}.")
            )
            return address
        except (OSError, ValueError) as exc:
            checks.append(
                _check(
                    "endpoint_dns_fail", "Server resolution", CheckStatus.FAIL,
                    f"The VPN server cannot be resolved: {exc}",
                )
            )
            return ""

    def _check_endpoint_route(self, endpoint_ip: str, checks: list[CheckResult]) -> None:
        if not shutil.which("ip"):
            return
        result = self.runner.run(["ip", "route", "get", endpoint_ip], timeout=6)
        if result.ok and result.stdout.strip():
            checks.append(
                _check("endpoint_route", "Route to VPN server", CheckStatus.PASS, result.stdout.strip())
            )
        else:
            checks.append(
                _check(
                    "endpoint_no_route", "Route to VPN server", CheckStatus.FAIL,
                    "There is no usable route to the VPN endpoint before entering the tunnel.",
                )
            )

    def _local_networks(self) -> list[str]:
        if not shutil.which("ip"):
            return []
        result = self.runner.run(["ip", "-o", "-4", "address", "show", "scope", "global"], timeout=6)
        networks: list[str] = []
        if result.ok:
            for match in re.finditer(r"\binet\s+(\d+\.\d+\.\d+\.\d+/\d+)", result.stdout):
                try:
                    networks.append(str(ipaddress.ip_interface(match.group(1)).network))
                except ValueError:
                    pass
        return networks

    def _check_overlap(self, profile: ProfileRecord, checks: list[CheckResult]) -> None:
        remote = []
        for raw in profile.expected_subnets:
            try:
                network = ipaddress.ip_network(raw, strict=False)
                if network.prefixlen > 1:
                    remote.append(str(network))
            except ValueError:
                pass
        overlap = networks_overlap(self._local_networks(), remote)
        if overlap:
            detail = "; ".join(f"local {local} overlaps VPN {vpn}" for local, vpn in overlap)
            checks.append(
                _check(
                    "subnet_overlap", "Subnet overlap", CheckStatus.FAIL,
                    detail + ". This cannot be repaired safely on the client; change one network or use a translated VPN subnet.",
                )
            )
        elif remote:
            checks.append(
                _check("subnet_overlap", "Subnet overlap", CheckStatus.PASS, "No conflicting local subnet was found.")
            )

    def _route_target(self, profile: ProfileRecord) -> str:
        if profile.test_host:
            try:
                return socket.getaddrinfo(profile.test_host, None, type=socket.SOCK_DGRAM)[0][4][0]
            except OSError:
                return profile.test_host
        for raw in profile.expected_subnets:
            try:
                network = ipaddress.ip_network(raw, strict=False)
                if network.prefixlen <= 1:
                    continue
                return str(network.network_address + 1)
            except (ValueError, IndexError):
                continue
        return ""

    def _check_expected_route(self, profile: ProfileRecord, checks: list[CheckResult]) -> None:
        target = self._route_target(profile)
        if not target or not shutil.which("ip"):
            return
        result = self.runner.run(["ip", "route", "get", target], timeout=6)
        text = result.stdout.strip()
        if result.ok and text and not re.search(r"\b(unreachable|prohibit|blackhole)\b", text):
            checks.append(_check("route", "VPN route", CheckStatus.PASS, text))
        else:
            checks.append(
                _check(
                    "route_missing", "VPN route", CheckStatus.FAIL,
                    f"No usable VPN route was found for {target}.", "restore-routes",
                )
            )

    def _check_dns(self, profile: ProfileRecord, checks: list[CheckResult]) -> None:
        if not profile.dns_search and not profile.test_host:
            return
        test_name = profile.test_host
        if not test_name and profile.dns_search:
            checks.append(
                _check(
                    "dns_config", "Split DNS", CheckStatus.INFO,
                    f"DNS routing domain ~{profile.dns_search} is configured; add a test hostname for an end-to-end lookup.",
                )
            )
            return
        try:
            addresses = socket.getaddrinfo(test_name, None)
            resolved = sorted({item[4][0] for item in addresses})
            checks.append(
                _check("dns", "VPN DNS", CheckStatus.PASS, f"{test_name} resolves to {', '.join(resolved[:4])}.")
            )
        except socket.gaierror as exc:
            checks.append(
                _check(
                    "dns_fail", "VPN DNS", CheckStatus.FAIL,
                    f"{test_name} did not resolve: {exc}", "restore-dns",
                )
            )

    def _check_reachability(self, profile: ProfileRecord, checks: list[CheckResult]) -> None:
        host = profile.test_host
        if not host:
            return
        if shutil.which("ping"):
            small = self.runner.run(["ping", "-c", "2", "-W", "2", host], timeout=7)
            if small.ok:
                checks.append(_check("ping", "Internal host ping", CheckStatus.PASS, f"{host} replied."))
                if profile.protocol == Protocol.WIREGUARD:
                    large = self.runner.run(
                        ["ping", "-4", "-c", "1", "-W", "2", "-M", "do", "-s", "1320", host],
                        timeout=5,
                    )
                    if not large.ok and "invalid" not in large.stderr.lower():
                        checks.append(
                            _check(
                                "mtu_suspected", "Tunnel MTU", CheckStatus.WARN,
                                "Small packets pass but a 1320-byte no-fragment ping fails. A lower WireGuard MTU may help.",
                                "lower-wireguard-mtu",
                            )
                        )
            else:
                checks.append(
                    _check(
                        "ping_fail", "Internal host ping", CheckStatus.WARN,
                        f"{host} did not answer ICMP. The host or firewall may block ping.",
                    )
                )
        if profile.test_port:
            try:
                with socket.create_connection((host, profile.test_port), timeout=3):
                    pass
                checks.append(
                    _check(
                        "tcp_test", "Internal service", CheckStatus.PASS,
                        f"TCP {host}:{profile.test_port} is reachable.",
                    )
                )
            except OSError as exc:
                checks.append(
                    _check(
                        "tcp_fail", "Internal service", CheckStatus.FAIL,
                        f"TCP {host}:{profile.test_port} is not reachable: {exc}",
                    )
                )

    def _check_wireguard(self, profile: ProfileRecord, checks: list[CheckResult]) -> None:
        if not shutil.which("wg"):
            checks.append(
                _check(
                    "wg_tool_missing", "WireGuard handshake", CheckStatus.WARN,
                    "wg is unavailable, so handshake age cannot be inspected.",
                    "install-dependencies",
                )
            )
            return
        result = self.runner.run(["wg", "show", "all", "latest-handshakes"], timeout=6)
        if not result.ok:
            checks.append(
                _check(
                    "wg_inspection_unavailable", "WireGuard handshake", CheckStatus.WARN,
                    "The tunnel is active, but handshake details are not readable by this user.",
                )
            )
            return
        timestamps: list[int] = []
        if result.ok:
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 3 and parts[-1].isdigit():
                    timestamps.append(int(parts[-1]))
        newest = max(timestamps, default=0)
        if newest and time.time() - newest < 180:
            age = int(time.time() - newest)
            checks.append(
                _check("wg_handshake", "WireGuard handshake", CheckStatus.PASS, f"Latest handshake was {age}s ago.")
            )
        elif newest:
            checks.append(
                _check(
                    "wg_handshake_old", "WireGuard handshake", CheckStatus.WARN,
                    "The most recent handshake is stale. Check the endpoint, server peer, clock, and UDP forwarding.",
                )
            )
        else:
            checks.append(
                _check(
                    "wg_no_handshake", "WireGuard handshake", CheckStatus.FAIL,
                    "No handshake is visible. Common causes are a wrong key/endpoint, missing server peer, blocked UDP, or missing port forwarding.",
                )
            )

    def _classify_recent_logs(self, profile: ProfileRecord) -> list[CheckResult]:
        if not shutil.which("journalctl"):
            return []
        logs = self.runner.run(
            ["journalctl", "-u", "NetworkManager", "--since", "-5 minutes", "--no-pager", "-n", "160"],
            timeout=10,
        )
        text = (logs.stdout + "\n" + logs.stderr).lower()
        patterns = [
            ("auth_log", r"authentication failed|no valid secrets|secrets were required", "Authentication failure", "The recent NetworkManager log reports rejected or missing credentials."),
            ("proposal_log", r"no proposal chosen|no acceptable proposal", "IPsec proposal mismatch", "The client and server could not agree on IPsec encryption settings."),
            ("plugin_log", r"vpn plugin.*not found|service.*unknown|failed to load.*plugin", "VPN plugin missing", "NetworkManager reports that the required VPN plugin is missing."),
            ("timeout_log", r"connection.*timed out|negotiation.*timed out", "VPN negotiation timeout", "Negotiation timed out. Check the endpoint, firewall, NAT, and server listener."),
        ]
        found: list[CheckResult] = []
        for code, pattern, title, detail in patterns:
            if re.search(pattern, text):
                found.append(_check(code, title, CheckStatus.FAIL, detail))
        return found
