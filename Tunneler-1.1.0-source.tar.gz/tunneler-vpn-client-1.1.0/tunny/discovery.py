from __future__ import annotations

import concurrent.futures
import re
import shutil
import socket
import ssl
from collections.abc import Iterable

from .command import CommandRunner
from .models import DiscoveryResult, Protocol
from .validation import ValidationError, split_endpoint, validate_host


SERVICE_MAP: dict[str, tuple[Protocol, int]] = {
    "_wireguard._udp": (Protocol.WIREGUARD, 51820),
    "_openvpn._udp": (Protocol.OPENVPN, 1194),
    "_openvpn._tcp": (Protocol.OPENVPN, 1194),
    "_l2tp._udp": (Protocol.L2TP, 1701),
    "_ipsec._udp": (Protocol.IKEV2, 500),
    "_openconnect._tcp": (Protocol.OPENCONNECT, 443),
}


class DiscoveryEngine:
    """Conservative discovery: no broad subnet scan and no claim that silent UDP is open."""

    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    def discover(self, seed: str = "") -> list[DiscoveryResult]:
        results: list[DiscoveryResult] = []
        if seed.strip():
            host, explicit_port = split_endpoint(seed.strip())
            results.extend(self._dns_srv(host))
            results.extend(self._probe_known_host(host, explicit_port))
        else:
            results.extend(self._mdns())
            candidates = self._local_candidates()
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                futures = [pool.submit(self._probe_known_host, host, None) for host in candidates]
                for future in concurrent.futures.as_completed(futures):
                    try:
                        results.extend(future.result())
                    except OSError:
                        continue
        return self._deduplicate(results)

    def _probe_known_host(self, host: str, explicit_port: int | None) -> list[DiscoveryResult]:
        try:
            socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        except socket.gaierror:
            return []
        udp_conventions = {
            500: Protocol.IKEV2,
            4500: Protocol.IKEV2,
            1701: Protocol.L2TP,
            51820: Protocol.WIREGUARD,
        }
        results: list[DiscoveryResult] = []
        if explicit_port in udp_conventions:
            protocol = udp_conventions[explicit_port]
            results.append(
                DiscoveryResult(
                    protocol=protocol,
                    endpoint=host,
                    port=explicit_port,
                    source="Port convention",
                    confidence="possible",
                    detail="This is a common UDP port for the protocol; a silent UDP service cannot be proven by a safe probe.",
                )
            )
            return results
        ports = [explicit_port] if explicit_port else [443, 1194]
        for port in ports:
            if port is None or not self._tcp_open(host, port):
                continue
            if port == 443:
                detail = self._https_hint(host, port)
                results.append(
                    DiscoveryResult(
                        protocol=Protocol.OPENCONNECT,
                        endpoint=host,
                        port=port,
                        source="HTTPS probe",
                        confidence="possible",
                        detail=detail or "HTTPS is reachable; confirm the server type.",
                    )
                )
            elif port == 1194:
                results.append(
                    DiscoveryResult(
                        protocol=Protocol.OPENVPN,
                        endpoint=host,
                        port=port,
                        source="TCP probe",
                        confidence="possible",
                        detail="TCP 1194 is reachable; OpenVPN may still use UDP instead.",
                    )
                )
        return results

    @staticmethod
    def _tcp_open(host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=1.4):
                return True
        except OSError:
            return False

    @staticmethod
    def _https_hint(host: str, port: int) -> str:
        request_host = host
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            with socket.create_connection((host, port), timeout=2.0) as raw:
                with context.wrap_socket(raw, server_hostname=request_host) as tls:
                    tls.settimeout(2.0)
                    tls.sendall(
                        f"HEAD / HTTP/1.0\r\nHost: {request_host}\r\nUser-Agent: Tunneler/1.1\r\n\r\n".encode()
                    )
                    response = tls.recv(1024).decode("iso-8859-1", errors="replace")
            first = response.splitlines()[0] if response else ""
            return first[:160]
        except OSError:
            return "TLS accepted a connection but did not return a simple HTTP response."

    def _dns_srv(self, domain: str) -> list[DiscoveryResult]:
        results: list[DiscoveryResult] = []
        if shutil.which("resolvectl"):
            for service, (protocol, default_port) in SERVICE_MAP.items():
                query = f"{service}.{domain}"
                output = self.runner.run(
                    ["resolvectl", "query", "--type=SRV", query], timeout=4
                )
                if not output.ok:
                    continue
                for line in output.stdout.splitlines():
                    match = re.search(r"\bSRV\s+\d+\s+\d+\s+(\d+)\s+([^\s]+)", line)
                    if match:
                        results.append(
                            DiscoveryResult(
                                protocol=protocol,
                                endpoint=match.group(2).rstrip("."),
                                port=int(match.group(1)) or default_port,
                                source="DNS SRV",
                                confidence="likely",
                                detail=f"Published by {query}",
                            )
                        )
        elif shutil.which("dig"):
            for service, (protocol, default_port) in SERVICE_MAP.items():
                query = f"{service}.{domain}"
                output = self.runner.run(["dig", "+short", "SRV", query], timeout=4)
                if not output.ok:
                    continue
                for line in output.stdout.splitlines():
                    parts = line.split()
                    if len(parts) == 4 and parts[2].isdigit():
                        results.append(
                            DiscoveryResult(
                                protocol=protocol,
                                endpoint=parts[3].rstrip("."),
                                port=int(parts[2]) or default_port,
                                source="DNS SRV",
                                confidence="likely",
                                detail=f"Published by {query}",
                            )
                        )
        return results

    def _mdns(self) -> list[DiscoveryResult]:
        if not shutil.which("avahi-browse"):
            return []
        output = self.runner.run(["avahi-browse", "-a", "-r", "-p", "-t"], timeout=8)
        if not output.ok:
            return []
        results: list[DiscoveryResult] = []
        for line in output.stdout.splitlines():
            if not line.startswith("="):
                continue
            fields = line.split(";")
            if len(fields) < 9:
                continue
            service_type = fields[4]
            mapping = SERVICE_MAP.get(service_type)
            if not mapping:
                continue
            protocol, default_port = mapping
            host = fields[7].rstrip(".")
            port = int(fields[8]) if fields[8].isdigit() else default_port
            try:
                validate_host(host)
            except ValidationError:
                continue
            results.append(
                DiscoveryResult(
                    protocol=protocol,
                    endpoint=host,
                    port=port,
                    source="Local mDNS",
                    confidence="likely",
                    detail=f"Advertised as {service_type}",
                )
            )
        return results

    def _local_candidates(self) -> list[str]:
        if not shutil.which("ip"):
            return []
        candidates: list[str] = []
        default = self.runner.run(["ip", "route", "show", "default"], timeout=5)
        if default.ok:
            for line in default.stdout.splitlines():
                match = re.search(r"\bvia\s+(\S+)", line)
                if match:
                    candidates.append(match.group(1))
        neighbors = self.runner.run(["ip", "neighbor", "show"], timeout=5)
        if neighbors.ok:
            for line in neighbors.stdout.splitlines():
                parts = line.split()
                if parts and any(state in parts for state in ("REACHABLE", "STALE", "DELAY")):
                    candidates.append(parts[0])
        valid: list[str] = []
        for item in candidates[:32]:
            try:
                valid.append(validate_host(item))
            except ValidationError:
                pass
        return list(dict.fromkeys(valid))

    @staticmethod
    def _deduplicate(results: Iterable[DiscoveryResult]) -> list[DiscoveryResult]:
        unique: dict[tuple[str, str, int], DiscoveryResult] = {}
        rank = {"possible": 1, "likely": 2, "certain": 3}
        for item in results:
            key = (item.protocol.value, item.endpoint, item.port)
            previous = unique.get(key)
            if previous is None or rank.get(item.confidence, 0) > rank.get(previous.confidence, 0):
                unique[key] = item
        return sorted(
            unique.values(), key=lambda item: (-rank.get(item.confidence, 0), item.protocol.value, item.endpoint)
        )
