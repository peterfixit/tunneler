from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from .models import Protocol


@dataclass(frozen=True, slots=True)
class Distribution:
    family: str
    distro_id: str
    name: str
    package_manager: str


PACKAGE_MAP: dict[str, dict[Protocol, tuple[str, ...]]] = {
    "arch": {
        Protocol.WIREGUARD: ("networkmanager", "wireguard-tools"),
        Protocol.OPENVPN: ("networkmanager", "networkmanager-openvpn", "openvpn"),
        Protocol.L2TP: (
            "networkmanager", "networkmanager-l2tp", "strongswan", "xl2tpd",
        ),
        Protocol.IKEV2: ("networkmanager", "networkmanager-strongswan", "strongswan"),
        Protocol.OPENCONNECT: (
            "networkmanager", "networkmanager-openconnect", "openconnect",
        ),
    },
    "fedora": {
        Protocol.WIREGUARD: ("NetworkManager", "wireguard-tools"),
        Protocol.OPENVPN: ("NetworkManager", "NetworkManager-openvpn", "openvpn"),
        Protocol.L2TP: ("NetworkManager", "NetworkManager-l2tp", "xl2tpd", "strongswan"),
        Protocol.IKEV2: ("NetworkManager", "NetworkManager-strongswan", "strongswan"),
        Protocol.OPENCONNECT: ("NetworkManager", "NetworkManager-openconnect", "openconnect"),
    },
    "debian": {
        Protocol.WIREGUARD: ("network-manager", "wireguard-tools"),
        Protocol.OPENVPN: ("network-manager", "network-manager-openvpn", "openvpn"),
        Protocol.L2TP: (
            "network-manager", "network-manager-l2tp", "xl2tpd", "strongswan",
        ),
        Protocol.IKEV2: ("network-manager", "network-manager-strongswan", "strongswan"),
        Protocol.OPENCONNECT: (
            "network-manager", "network-manager-openconnect", "openconnect",
        ),
    },
    "suse": {
        Protocol.WIREGUARD: ("NetworkManager", "wireguard-tools"),
        Protocol.OPENVPN: ("NetworkManager", "NetworkManager-openvpn", "openvpn"),
        Protocol.L2TP: (
            "NetworkManager", "NetworkManager-l2tp", "xl2tpd", "strongswan",
        ),
        Protocol.IKEV2: ("NetworkManager", "NetworkManager-strongswan", "strongswan"),
        Protocol.OPENCONNECT: (
            "NetworkManager", "NetworkManager-openconnect", "openconnect",
        ),
    },
}


def read_os_release(path: Path = Path("/etc/os-release")) -> dict[str, str]:
    data: dict[str, str] = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            data[key] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return data


def detect_distribution(path: Path = Path("/etc/os-release")) -> Distribution:
    data = read_os_release(path)
    distro_id = data.get("ID", "unknown").lower()
    like = set(data.get("ID_LIKE", "").lower().split())
    names = {distro_id, *like}
    if names & {"arch", "cachyos", "manjaro", "endeavouros", "garuda"}:
        family, manager = "arch", "pacman"
    elif names & {"fedora", "rhel", "centos", "nobara"}:
        family, manager = "fedora", "dnf"
    elif names & {"debian", "ubuntu", "linuxmint", "pop", "kubuntu", "neon"}:
        family, manager = "debian", "apt-get"
    elif names & {"opensuse", "opensuse-tumbleweed", "suse"}:
        family, manager = "suse", "zypper"
    else:
        family = "unknown"
        manager = next(
            (name for name in ("pacman", "dnf", "apt-get", "zypper") if shutil.which(name)),
            "",
        )
        family = {
            "pacman": "arch", "dnf": "fedora", "apt-get": "debian", "zypper": "suse",
        }.get(manager, "unknown")
    return Distribution(
        family=family,
        distro_id=distro_id,
        name=data.get("PRETTY_NAME", distro_id or "Unknown Linux"),
        package_manager=manager,
    )


def packages_for(distribution: Distribution, protocol: Protocol) -> tuple[str, ...]:
    try:
        return PACKAGE_MAP[distribution.family][protocol]
    except KeyError as exc:
        raise RuntimeError(
            f"Automatic package installation is not available for {distribution.name}."
        ) from exc


def package_command(distribution: Distribution, packages: tuple[str, ...]) -> list[list[str]]:
    if not packages:
        return []
    if distribution.family == "arch":
        return [["pacman", "-S", "--needed", "--noconfirm", *packages]]
    if distribution.family == "fedora":
        return [["dnf", "install", "-y", *packages]]
    if distribution.family == "debian":
        return [
            ["apt-get", "update"],
            ["apt-get", "install", "-y", "--no-install-recommends", *packages],
        ]
    if distribution.family == "suse":
        return [["zypper", "--non-interactive", "install", *packages]]
    raise RuntimeError(f"Unsupported distribution family: {distribution.family}")


def protocol_tools(protocol: Protocol) -> tuple[str, ...]:
    return {
        Protocol.WIREGUARD: ("nmcli",),
        Protocol.OPENVPN: ("nmcli", "openvpn"),
        Protocol.L2TP: ("nmcli",),
        Protocol.IKEV2: ("nmcli",),
        Protocol.OPENCONNECT: ("nmcli", "openconnect"),
    }[protocol]


def missing_tools(protocol: Protocol) -> list[str]:
    return [name for name in protocol_tools(protocol) if shutil.which(name) is None]
