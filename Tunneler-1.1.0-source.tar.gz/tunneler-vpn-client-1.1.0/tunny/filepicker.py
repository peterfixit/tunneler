from __future__ import annotations

import fnmatch
import logging
import os
import shutil
import subprocess
import tkinter as tk
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from tkinter import ttk
from typing import Mapping, Sequence


LOGGER = logging.getLogger("tunny.filepicker")

DEFAULT_COLORS = {
    "window": "#0A0F1D",
    "surface": "#11192A",
    "surface_alt": "#172238",
    "primary": "#7C6CFF",
    "primary_hover": "#6A59F0",
    "text": "#F1F4FA",
    "muted": "#98A4B9",
    "border": "#25314A",
    "danger": "#FF7088",
    "input": "#0D1526",
}


@dataclass(frozen=True)
class FileType:
    label: str
    patterns: tuple[str, ...]


def _desktop_name(environment: Mapping[str, str] | None = None) -> str:
    env = environment if environment is not None else os.environ
    return ":".join(
        (env.get("XDG_CURRENT_DESKTOP", ""), env.get("DESKTOP_SESSION", ""))
    ).casefold()


def native_picker_backend(
    environment: Mapping[str, str] | None = None,
    which=shutil.which,
) -> str:
    """Return the best installed desktop-native picker, or an empty string."""
    desktop = _desktop_name(environment)
    if any(name in desktop for name in ("kde", "plasma")) and which("kdialog"):
        return "kdialog"
    if any(name in desktop for name in ("gnome", "cinnamon", "mate", "xfce")) and which("zenity"):
        return "zenity"
    if which("kdialog"):
        return "kdialog"
    if which("zenity"):
        return "zenity"
    return ""


def _kdialog_filter(filetypes: Sequence[FileType]) -> str:
    return "\n".join(
        f"{' '.join(item.patterns)}|{item.label}" for item in filetypes
    )


def _native_command(
    backend: str,
    title: str,
    initial_directory: Path,
    filetypes: Sequence[FileType],
) -> list[str]:
    start = str(initial_directory) + os.sep
    if backend == "kdialog":
        return [
            "kdialog",
            "--title",
            title,
            "--getopenfilename",
            start,
            _kdialog_filter(filetypes),
        ]
    if backend == "zenity":
        command = [
            "zenity",
            "--file-selection",
            f"--title={title}",
            f"--filename={start}",
        ]
        command.extend(
            f"--file-filter={item.label} | {' '.join(item.patterns)}"
            for item in filetypes
        )
        return command
    raise ValueError(f"Unknown file picker backend: {backend}")


def _run_native_picker(
    backend: str,
    title: str,
    initial_directory: Path,
    filetypes: Sequence[FileType],
) -> tuple[bool, str]:
    """Return (handled, path). An empty handled path means the user cancelled."""
    try:
        result = subprocess.run(
            _native_command(backend, title, initial_directory, filetypes),
            check=False,
            capture_output=True,
            text=True,
        )
    except (OSError, ValueError) as exc:
        LOGGER.warning("Native file picker could not start: %s", exc)
        return False, ""
    if result.returncode == 0:
        selected = result.stdout.strip()
        if selected:
            return True, selected
        return False, ""
    if result.returncode in {1, 255}:
        return True, ""
    LOGGER.warning(
        "Native file picker exited with status %s: %s",
        result.returncode,
        result.stderr.strip(),
    )
    return False, ""


def _usable_directory(value: str | Path | None) -> Path:
    candidate = Path(value).expanduser() if value else Path.home()
    if candidate.is_file():
        candidate = candidate.parent
    if candidate.is_dir():
        return candidate
    return Path.home()


def choose_file(
    parent: tk.Misc,
    *,
    title: str,
    filetypes: Sequence[FileType],
    initial_directory: str | Path | None = None,
    colors: Mapping[str, str] | None = None,
) -> str:
    """Choose one existing file without depending on a toolkit outside the AppImage."""
    directory = _usable_directory(initial_directory)
    backend = native_picker_backend()
    if backend:
        handled, selected = _run_native_picker(backend, title, directory, filetypes)
        if handled:
            return selected
    picker = IncludedFilePicker(
        parent,
        title=title,
        filetypes=filetypes,
        initial_directory=directory,
        colors=colors,
    )
    return picker.show()


class IncludedFilePicker:
    """A dark, self-contained file browser used when no native picker exists."""

    def __init__(
        self,
        parent: tk.Misc,
        *,
        title: str,
        filetypes: Sequence[FileType],
        initial_directory: Path,
        colors: Mapping[str, str] | None = None,
    ) -> None:
        self.parent = parent
        self.colors = dict(DEFAULT_COLORS)
        if colors:
            self.colors.update(colors)
        self.filetypes = tuple(filetypes) or (FileType("All files", ("*",)),)
        self.current_directory = initial_directory
        self.result = ""
        self.entries: dict[str, Path] = {}
        self.history: list[Path] = []
        self.history_index = -1

        self.window = tk.Toplevel(parent)
        self.window.title(title)
        self.window.geometry("920x620")
        self.window.minsize(760, 500)
        self.window.configure(bg=self.colors["window"])
        self.window.transient(parent.winfo_toplevel())
        self.window.protocol("WM_DELETE_WINDOW", self._cancel)
        self.window.bind("<Escape>", lambda _event: self._cancel())
        self.window.bind("<BackSpace>", lambda _event: self._go_up())

        self.path_var = tk.StringVar(value=str(initial_directory))
        self.filename_var = tk.StringVar()
        self.filter_var = tk.StringVar(value=self.filetypes[0].label)
        self.hidden_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="")
        self._style_widgets()
        self._build(title)
        self._navigate(initial_directory)

    def _style_widgets(self) -> None:
        style = ttk.Style(self.window)
        style.configure(
            "Picker.Treeview",
            background=self.colors["surface"],
            fieldbackground=self.colors["surface"],
            foreground=self.colors["text"],
            bordercolor=self.colors["border"],
            rowheight=31,
            font=("Noto Sans", 10),
        )
        style.map(
            "Picker.Treeview",
            background=[("selected", self.colors["primary"])],
            foreground=[("selected", "white")],
        )
        style.configure(
            "Picker.Treeview.Heading",
            background=self.colors["surface_alt"],
            foreground=self.colors["text"],
            relief="flat",
            font=("Noto Sans", 9, "bold"),
            padding=(8, 8),
        )
        style.map(
            "Picker.Treeview.Heading",
            background=[("active", self.colors["border"])],
        )
        style.configure(
            "Picker.TEntry",
            fieldbackground=self.colors["input"],
            foreground=self.colors["text"],
            insertcolor=self.colors["text"],
            bordercolor=self.colors["border"],
            lightcolor=self.colors["border"],
            darkcolor=self.colors["border"],
            padding=8,
        )
        style.configure(
            "Picker.TCombobox",
            fieldbackground=self.colors["input"],
            foreground=self.colors["text"],
            background=self.colors["surface_alt"],
            arrowcolor=self.colors["muted"],
            bordercolor=self.colors["border"],
            padding=7,
        )
        style.map(
            "Picker.TCombobox",
            fieldbackground=[("readonly", self.colors["input"])],
            foreground=[("readonly", self.colors["text"])],
            selectbackground=[("readonly", self.colors["input"])],
            selectforeground=[("readonly", self.colors["text"])],
        )

    def _button(
        self,
        parent: tk.Misc,
        text: str,
        command,
        *,
        primary: bool = False,
        width: int = 0,
    ) -> tk.Button:
        background = self.colors["primary"] if primary else self.colors["surface_alt"]
        active = self.colors["primary_hover"] if primary else self.colors["border"]
        return tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            bg=background,
            fg="white" if primary else self.colors["text"],
            activebackground=active,
            activeforeground="white",
            relief="flat",
            bd=0,
            padx=13,
            pady=8,
            font=("Noto Sans", 9, "bold"),
            cursor="hand2",
        )

    def _build(self, title: str) -> None:
        header = tk.Frame(self.window, bg=self.colors["window"])
        header.pack(fill="x", padx=24, pady=(20, 14))
        tk.Label(
            header,
            text=title,
            bg=self.colors["window"],
            fg=self.colors["text"],
            font=("Noto Sans", 17, "bold"),
        ).pack(side="left")
        tk.Label(
            header,
            text="Tunneler file browser",
            bg=self.colors["window"],
            fg=self.colors["muted"],
            font=("Noto Sans", 9),
        ).pack(side="right")

        toolbar = tk.Frame(self.window, bg=self.colors["surface"])
        toolbar.pack(fill="x", padx=24, pady=(0, 12))
        self.back_button = self._button(toolbar, "←", self._go_back, width=2)
        self.back_button.pack(side="left", padx=(0, 5), pady=8)
        self._button(toolbar, "↑", self._go_up, width=2).pack(side="left", padx=(0, 8), pady=8)
        path_entry = ttk.Entry(toolbar, textvariable=self.path_var, style="Picker.TEntry")
        path_entry.pack(side="left", fill="x", expand=True, pady=8)
        path_entry.bind("<Return>", lambda _event: self._open_typed_path())
        self._button(toolbar, "Go", self._open_typed_path).pack(side="left", padx=8, pady=8)
        self._button(toolbar, "↻", self._refresh, width=2).pack(side="left", padx=(0, 8), pady=8)

        body = tk.Frame(self.window, bg=self.colors["window"])
        body.pack(fill="both", expand=True, padx=24)
        places = tk.Frame(
            body,
            bg=self.colors["surface"],
            width=176,
            highlightbackground=self.colors["border"],
            highlightthickness=1,
        )
        places.pack(side="left", fill="y", padx=(0, 12))
        places.pack_propagate(False)
        tk.Label(
            places,
            text="PLACES",
            bg=self.colors["surface"],
            fg=self.colors["muted"],
            font=("Noto Sans", 8, "bold"),
        ).pack(anchor="w", padx=14, pady=(15, 7))
        for label, location in self._places():
            tk.Button(
                places,
                text=label,
                command=lambda path=location: self._navigate(path),
                anchor="w",
                bg=self.colors["surface"],
                fg=self.colors["text"],
                activebackground=self.colors["surface_alt"],
                activeforeground=self.colors["text"],
                relief="flat",
                bd=0,
                padx=14,
                pady=9,
                font=("Noto Sans", 9),
                cursor="hand2",
            ).pack(fill="x")

        list_frame = tk.Frame(
            body,
            bg=self.colors["surface"],
            highlightbackground=self.colors["border"],
            highlightthickness=1,
        )
        list_frame.pack(side="left", fill="both", expand=True)
        self.tree = ttk.Treeview(
            list_frame,
            columns=("name", "modified", "size"),
            show="headings",
            selectmode="browse",
            style="Picker.Treeview",
        )
        self.tree.heading("name", text="Name", anchor="w")
        self.tree.heading("modified", text="Modified", anchor="w")
        self.tree.heading("size", text="Size", anchor="e")
        self.tree.column("name", width=390, minwidth=180, stretch=True)
        self.tree.column("modified", width=145, minwidth=110, stretch=False)
        self.tree.column("size", width=86, minwidth=70, stretch=False, anchor="e")
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._selected)
        self.tree.bind("<Double-1>", self._activate_selection)
        self.tree.bind("<Return>", self._activate_selection)

        footer = tk.Frame(self.window, bg=self.colors["window"])
        footer.pack(fill="x", padx=24, pady=(12, 20))
        options = tk.Frame(footer, bg=self.colors["window"])
        options.pack(fill="x")
        tk.Checkbutton(
            options,
            text="Show hidden files",
            variable=self.hidden_var,
            command=self._refresh,
            bg=self.colors["window"],
            fg=self.colors["muted"],
            activebackground=self.colors["window"],
            activeforeground=self.colors["text"],
            selectcolor=self.colors["input"],
            font=("Noto Sans", 9),
        ).pack(side="left")
        self.filter_box = ttk.Combobox(
            options,
            state="readonly",
            textvariable=self.filter_var,
            values=tuple(item.label for item in self.filetypes),
            style="Picker.TCombobox",
            width=28,
        )
        self.filter_box.pack(side="right")
        self.filter_box.bind("<<ComboboxSelected>>", lambda _event: self._refresh())

        selection_row = tk.Frame(footer, bg=self.colors["window"])
        selection_row.pack(fill="x", pady=(10, 0))
        tk.Label(
            selection_row,
            text="File name",
            bg=self.colors["window"],
            fg=self.colors["muted"],
        ).pack(side="left", padx=(0, 8))
        filename = ttk.Entry(
            selection_row,
            textvariable=self.filename_var,
            style="Picker.TEntry",
        )
        filename.pack(side="left", fill="x", expand=True)
        filename.bind("<Return>", lambda _event: self._accept())
        self._button(selection_row, "Cancel", self._cancel).pack(side="left", padx=(10, 6))
        self._button(selection_row, "Open", self._accept, primary=True).pack(side="left")
        tk.Label(
            footer,
            textvariable=self.status_var,
            bg=self.colors["window"],
            fg=self.colors["danger"],
            anchor="w",
            font=("Noto Sans", 9),
        ).pack(fill="x", pady=(7, 0))

    def _places(self) -> list[tuple[str, Path]]:
        home = Path.home()
        values: list[tuple[str, Path]] = [("⌂  Home", home)]
        for name in ("Downloads", "Documents", "Desktop"):
            path = home / name
            if path.is_dir():
                values.append((f"•  {name}", path))
        values.append(("/  Computer", Path("/")))
        seen = {path.resolve() for _, path in values if path.exists()}
        for root in (Path("/run/media") / home.name, Path("/media") / home.name):
            if not root.is_dir():
                continue
            try:
                children = sorted(root.iterdir(), key=lambda item: item.name.casefold())
            except OSError:
                continue
            for child in children:
                if child.is_dir() and child.resolve() not in seen:
                    values.append((f"◉  {child.name}", child))
                    seen.add(child.resolve())
        if Path("/mnt").is_dir():
            values.append(("◉  Mounted files", Path("/mnt")))
        return values

    def _active_patterns(self) -> tuple[str, ...]:
        for item in self.filetypes:
            if item.label == self.filter_var.get():
                return item.patterns
        return ("*",)

    def _matches(self, name: str) -> bool:
        lowered = name.casefold()
        return any(fnmatch.fnmatch(lowered, pattern.casefold()) for pattern in self._active_patterns())

    @staticmethod
    def _size(value: int) -> str:
        size = float(value)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024 or unit == "TB":
                return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
            size /= 1024
        return ""

    def _navigate(self, path: Path, *, add_history: bool = True) -> None:
        try:
            target = path.expanduser().resolve()
            if not target.is_dir():
                raise NotADirectoryError(str(target))
            items = list(target.iterdir())
        except (OSError, RuntimeError) as exc:
            self.status_var.set(f"Cannot open this folder: {exc}")
            return
        self.current_directory = target
        self.path_var.set(str(target))
        self.status_var.set("")
        if add_history:
            del self.history[self.history_index + 1 :]
            self.history.append(target)
            self.history_index = len(self.history) - 1
        self._populate(items)
        self.back_button.configure(state="normal" if self.history_index > 0 else "disabled")

    def _populate(self, paths: Sequence[Path]) -> None:
        self.tree.delete(*self.tree.get_children())
        self.entries.clear()
        show_hidden = self.hidden_var.get()
        candidates: list[tuple[bool, str, Path]] = []
        for path in paths:
            if not show_hidden and path.name.startswith("."):
                continue
            try:
                is_directory = path.is_dir()
            except OSError:
                continue
            if not is_directory and not self._matches(path.name):
                continue
            candidates.append((not is_directory, path.name.casefold(), path))
        for is_file, _sort_name, path in sorted(candidates):
            try:
                stat = path.stat()
                modified = datetime.fromtimestamp(stat.st_mtime).strftime("%d %b %Y  %H:%M")
                size = self._size(stat.st_size) if is_file else "—"
            except (OSError, ValueError, OverflowError):
                modified, size = "—", "—"
            prefix = "  " if is_file else "▸  "
            iid = self.tree.insert("", "end", values=(prefix + path.name, modified, size))
            self.entries[iid] = path

    def _refresh(self) -> None:
        self._navigate(self.current_directory, add_history=False)

    def _selected_path(self) -> Path | None:
        selection = self.tree.selection()
        return self.entries.get(selection[0]) if selection else None

    def _selected(self, _event=None) -> None:
        selected = self._selected_path()
        if selected and selected.is_file():
            self.filename_var.set(selected.name)

    def _activate_selection(self, _event=None) -> None:
        selected = self._selected_path()
        if selected is None:
            return
        if selected.is_dir():
            self._navigate(selected)
        else:
            self._accept()

    def _open_typed_path(self) -> None:
        candidate = Path(self.path_var.get()).expanduser()
        if not candidate.is_absolute():
            candidate = self.current_directory / candidate
        if candidate.is_file():
            self.result = str(candidate.resolve())
            self.window.destroy()
            return
        self._navigate(candidate)

    def _go_up(self) -> None:
        parent = self.current_directory.parent
        if parent != self.current_directory:
            self._navigate(parent)

    def _go_back(self) -> None:
        if self.history_index <= 0:
            return
        self.history_index -= 1
        self._navigate(self.history[self.history_index], add_history=False)
        self.back_button.configure(state="normal" if self.history_index > 0 else "disabled")

    def _accept(self) -> None:
        selected = self._selected_path()
        filename = self.filename_var.get().strip()
        candidate = selected if selected and selected.is_file() else self.current_directory / filename
        try:
            candidate = candidate.expanduser().resolve()
        except (OSError, RuntimeError):
            self.status_var.set("That file path is not valid.")
            return
        if candidate.is_dir():
            self._navigate(candidate)
            return
        if not candidate.is_file():
            self.status_var.set("Choose an existing file.")
            return
        self.result = str(candidate)
        self.window.destroy()

    def _cancel(self) -> None:
        self.result = ""
        self.window.destroy()

    def show(self) -> str:
        self.window.update_idletasks()
        self.window.wait_visibility()
        self.window.grab_set()
        self.window.focus_set()
        self.window.wait_window()
        return self.result
