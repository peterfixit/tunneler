from __future__ import annotations

import os
import re
import shlex
import shutil
import stat
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .models import Protocol, WireGuardConfig, WireGuardPeer
from .validation import (
    ValidationError,
    split_endpoint,
    validate_dns_search,
    validate_ip_list,
    validate_networks,
    validate_port,
    validate_wireguard_key,
)


MAX_CONFIG_SIZE = 2 * 1024 * 1024
MAX_REFERENCED_FILE_SIZE = 10 * 1024 * 1024
OPENVPN_BLOCKED = {
    "up", "down", "route-up", "route-pre-down", "ipchange", "learn-address",
    "client-connect", "client-disconnect", "tls-verify", "auth-user-pass-verify",
    "plugin", "management", "management-client-user", "management-client-group",
}
OPENVPN_FILE_DIRECTIVES = {"ca", "cert", "key", "pkcs12", "tls-auth", "tls-crypt"}
WIREGUARD_BLOCKED = {"preup", "postup", "predown", "postdown", "saveconfig"}


@dataclass(slots=True)
class InspectedConfig:
    protocol: Protocol
    path: Path
    endpoint: str = ""
    port: int | None = None
    allowed_ips: list[str] = field(default_factory=list)
    dns_servers: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    referenced_files: list[Path] = field(default_factory=list)
    wireguard: WireGuardConfig | None = None


def _read_config(path: Path) -> str:
    try:
        info = path.stat()
    except OSError as exc:
        raise ValidationError(f"Cannot read VPN configuration: {exc}") from exc
    if not stat.S_ISREG(info.st_mode):
        raise ValidationError("VPN configuration must be a regular file.")
    if info.st_size > MAX_CONFIG_SIZE:
        raise ValidationError("VPN configuration is larger than the 2 MiB safety limit.")
    try:
        return path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        raise ValidationError("VPN configuration is not readable UTF-8 text.") from exc


def inspect_config(path_value: str | Path) -> InspectedConfig:
    path = Path(path_value).expanduser().resolve()
    text = _read_config(path)
    lower = text.lower()
    if "[interface]" in lower and "[peer]" in lower:
        return _inspect_wireguard(path, text)
    if re.search(r"(?mi)^\s*(client|remote|dev|proto)\b", text):
        return _inspect_openvpn(path, text)
    raise ValidationError("This does not look like a WireGuard .conf or OpenVPN .ovpn file.")


def _inspect_wireguard(path: Path, text: str) -> InspectedConfig:
    parsed = parse_wireguard(text)
    result = InspectedConfig(protocol=Protocol.WIREGUARD, path=path, wireguard=parsed)
    if parsed.peers:
        result.endpoint = parsed.peers[0].endpoint
        result.port = parsed.peers[0].port
    for peer in parsed.peers:
        result.allowed_ips.extend(peer.allowed_ips)
    result.dns_servers = parsed.dns_servers
    if not result.endpoint:
        result.warnings.append("No peer endpoint was found; the profile may be server-only.")
    return result


def parse_wireguard(text: str) -> WireGuardConfig:
    interface: dict[str, str] = {}
    peer_maps: list[dict[str, str]] = []
    section = ""
    for number, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip().lower()
            if section == "peer":
                peer_maps.append({})
            elif section != "interface":
                raise ValidationError(f"Unsupported WireGuard section on line {number}: {line}")
            continue
        if "=" not in line:
            raise ValidationError(f"WireGuard line {number} must use Key = Value syntax.")
        key, value = (item.strip() for item in line.split("=", 1))
        if key.lower() in WIREGUARD_BLOCKED:
            raise ValidationError(
                f"WireGuard line {number} uses {key}, which could execute commands and is blocked."
            )
        lower_key = key.lower()
        if section == "interface":
            if lower_key == "table" and value.lower() not in {"auto", "main"}:
                raise ValidationError(
                    "WireGuard Table values other than auto/main cannot be translated safely to NetworkManager."
                )
            if lower_key not in {"privatekey", "address", "dns", "mtu", "listenport", "table"}:
                raise ValidationError(f"Unsupported WireGuard interface option: {key}")
            interface[lower_key] = value
        elif section == "peer" and peer_maps:
            if lower_key not in {"publickey", "presharedkey", "allowedips", "endpoint", "persistentkeepalive"}:
                raise ValidationError(f"Unsupported WireGuard peer option: {key}")
            peer_maps[-1][lower_key] = value
        else:
            raise ValidationError(f"WireGuard option appears before a section on line {number}.")

    private_key = validate_wireguard_key(interface.get("privatekey", ""), "Private key")
    addresses = validate_networks(
        [item.strip() for item in interface.get("address", "").split(",") if item.strip()],
        addresses=True,
    )
    if not addresses:
        raise ValidationError("WireGuard configuration has no interface Address.")
    raw_dns = [item.strip() for item in interface.get("dns", "").split(",") if item.strip()]
    dns_servers: list[str] = []
    dns_search = ""
    for item in raw_dns:
        try:
            dns_servers.extend(validate_ip_list([item]))
        except ValidationError:
            if dns_search:
                raise ValidationError("Only one WireGuard DNS search domain is supported.")
            dns_search = validate_dns_search(item)
    mtu = int(interface["mtu"]) if interface.get("mtu", "").isdigit() else None
    if interface.get("mtu") and mtu is None:
        raise ValidationError("WireGuard MTU must be numeric.")
    if mtu is not None and not 576 <= mtu <= 9000:
        raise ValidationError("WireGuard MTU must be between 576 and 9000.")
    listen_port = validate_port(interface.get("listenport"))

    peers: list[WireGuardPeer] = []
    for index, data in enumerate(peer_maps, start=1):
        public_key = validate_wireguard_key(data.get("publickey", ""), f"Peer {index} public key")
        psk = validate_wireguard_key(
            data.get("presharedkey", ""), f"Peer {index} preshared key", required=False
        )
        allowed = validate_networks(
            [item.strip() for item in data.get("allowedips", "").split(",") if item.strip()]
        )
        if not allowed:
            raise ValidationError(f"WireGuard peer {index} has no AllowedIPs.")
        endpoint = ""
        port = None
        if data.get("endpoint"):
            endpoint, port = split_endpoint(data["endpoint"], 51820)
        keepalive_text = data.get("persistentkeepalive", "0")
        if not keepalive_text.isdigit() or not 0 <= int(keepalive_text) <= 65535:
            raise ValidationError(f"WireGuard peer {index} has an invalid PersistentKeepalive.")
        peers.append(
            WireGuardPeer(
                public_key=public_key,
                allowed_ips=allowed,
                endpoint=endpoint,
                port=port,
                preshared_key=psk,
                persistent_keepalive=int(keepalive_text),
            )
        )
    if not peers:
        raise ValidationError("WireGuard configuration has no [Peer] section.")
    return WireGuardConfig(
        private_key=private_key,
        addresses=addresses,
        peers=peers,
        dns_servers=dns_servers,
        dns_search=dns_search,
        mtu=mtu,
        listen_port=listen_port,
    )


def _inspect_openvpn(path: Path, text: str) -> InspectedConfig:
    result = InspectedConfig(protocol=Protocol.OPENVPN, path=path)
    inline_block = ""
    for number, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("<") and line.endswith(">"):
            if line.startswith("</"):
                inline_block = ""
            else:
                inline_block = line.strip("<>").lower()
            continue
        if inline_block:
            continue
        try:
            parts = shlex.split(line, comments=True, posix=True)
        except ValueError as exc:
            raise ValidationError(f"Invalid quoting in OpenVPN line {number}.") from exc
        if not parts:
            continue
        directive = parts[0].lower().lstrip("-")
        if directive in OPENVPN_BLOCKED:
            raise ValidationError(
                f"OpenVPN line {number} uses blocked directive '{directive}' because it can execute code or expose a control socket."
            )
        if directive == "script-security" and len(parts) > 1 and parts[1] != "0":
            raise ValidationError("OpenVPN script execution is disabled for imported profiles.")
        if directive == "auth-user-pass" and len(parts) > 1:
            raise ValidationError(
                "OpenVPN auth-user-pass files are not imported. Enter credentials in Tunneler instead."
            )
        if directive == "remote" and len(parts) >= 2 and not result.endpoint:
            result.endpoint = parts[1]
            result.port = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 1194
        if directive in OPENVPN_FILE_DIRECTIVES and len(parts) >= 2:
            ref = Path(parts[1]).expanduser()
            if not ref.is_absolute():
                ref = path.parent / ref
            ref = ref.resolve()
            if ref != path and ref not in result.referenced_files:
                result.referenced_files.append(ref)
    return result


def stage_config(config: InspectedConfig, base_dir: Path) -> Path:
    """Copy a config and local certificate files into private persistent storage."""
    base_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(base_dir, 0o700)
    stage = Path(tempfile.mkdtemp(prefix="profile-", dir=base_dir))
    os.chmod(stage, 0o700)
    destination = stage / config.path.name
    text = _read_config(config.path)
    for reference in config.referenced_files:
        try:
            info = reference.stat()
        except OSError as exc:
            shutil.rmtree(stage, ignore_errors=True)
            raise ValidationError(f"Referenced VPN file is missing: {reference.name}") from exc
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_REFERENCED_FILE_SIZE:
            shutil.rmtree(stage, ignore_errors=True)
            raise ValidationError(f"Referenced VPN file is invalid or too large: {reference.name}")
        target = stage / reference.name
        shutil.copyfile(reference, target)
        os.chmod(target, 0o600)
        text = text.replace(str(reference), str(target))
        try:
            relative = str(reference.relative_to(config.path.parent))
            text = text.replace(relative, str(target))
        except ValueError:
            pass
    destination.write_text(text, encoding="utf-8")
    os.chmod(destination, 0o600)
    return destination
