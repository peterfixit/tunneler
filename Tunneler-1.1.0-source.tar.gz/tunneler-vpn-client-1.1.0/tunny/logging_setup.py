from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler

from .command import Redactor
from .settings import STATE_DIR


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = Redactor.text(str(record.msg))
        if record.args:
            record.args = tuple(Redactor.text(str(item)) for item in record.args)
        return True


def configure_logging(verbose: bool = False) -> str:
    STATE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(STATE_DIR, 0o700)
    log_path = STATE_DIR / "tunneler.log"
    handler = RotatingFileHandler(
        log_path, maxBytes=768 * 1024, backupCount=3, encoding="utf-8"
    )
    os.chmod(log_path, 0o600)
    handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    )
    handler.addFilter(RedactingFilter())
    root = logging.getLogger("tunny")
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.propagate = False
    return str(log_path)
