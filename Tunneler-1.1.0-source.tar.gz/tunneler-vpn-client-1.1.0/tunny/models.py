from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class Protocol(str, Enum):
    WIREGUARD = "wireguard"
    OPENVPN = "openvpn"
    L2TP = "l2tp"
    IKEV2 = "ikev2"
    OPENCONNECT = "openconnect"

    @property
    def label(self) -> str:
        return {
            Protocol.WIREGUARD: "WireGuard",
            Protocol.OPENVPN: "OpenVPN",
            Protocol.L2TP: "L2TP / IPsec",
            Protocol.IKEV2: "IKEv2 / IPsec",
            Protocol.OPENCONNECT: "OpenConnect",
        }[self]


class CheckStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    FIXED = "fixed"
    INFO = "info"


@dataclass(slots=True)
class ProfileRecord:
    name: str
    uuid: str
    protocol: Protocol
    endpoint: str = ""
    expected_subnets: list[str] = field(default_factory=list)
    dns_servers: list[str] = field(default_factory=list)
    dns_search: str = ""
    test_host: str = ""
    test_port: int | None = None
    full_tunnel: bool = False
    managed_by_tunny: bool = True
    created_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["protocol"] = self.protocol.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProfileRecord":
        allowed = {item.name for item in cls.__dataclass_fields__.values()}
        clean = {key: value for key, value in data.items() if key in allowed}
        clean["protocol"] = Protocol(clean["protocol"])
        return cls(**clean)


@dataclass(slots=True)
class ProfileDraft:
    name: str
    protocol: Protocol
    endpoint: str = ""
    username: str = ""
    password: str = ""
    ipsec_psk: str = ""
    private_key: str = ""
    public_key: str = ""
    preshared_key: str = ""
    interface_addresses: list[str] = field(default_factory=list)
    allowed_ips: list[str] = field(default_factory=list)
    dns_servers: list[str] = field(default_factory=list)
    dns_search: str = ""
    test_host: str = ""
    test_port: int | None = None
    port: int | None = None
    full_tunnel: bool = False
    openconnect_protocol: str = "anyconnect"
    persistent_keepalive: int = 25
    mtu: int | None = None
    certificate_path: str = ""
    remote_identity: str = ""


@dataclass(slots=True)
class WireGuardPeer:
    public_key: str
    allowed_ips: list[str]
    endpoint: str = ""
    port: int | None = None
    preshared_key: str = ""
    persistent_keepalive: int = 0


@dataclass(slots=True)
class WireGuardConfig:
    private_key: str
    addresses: list[str]
    peers: list[WireGuardPeer]
    dns_servers: list[str] = field(default_factory=list)
    dns_search: str = ""
    mtu: int | None = None
    listen_port: int | None = None


@dataclass(slots=True)
class Credentials:
    username: str = ""
    password: str = ""
    ipsec_psk: str = ""
    cert_password: str = ""


@dataclass(slots=True)
class DiscoveryResult:
    protocol: Protocol
    endpoint: str
    port: int
    source: str
    confidence: str
    detail: str = ""


@dataclass(slots=True)
class CheckResult:
    code: str
    title: str
    status: CheckStatus
    detail: str
    repair_id: str = ""


@dataclass(slots=True)
class CommandResult:
    args: list[str]
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False
    duration_seconds: float = 0.0

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out


@dataclass(slots=True)
class ConnectionOutcome:
    connected: bool
    message: str
    checks: list[CheckResult] = field(default_factory=list)
    repaired: list[str] = field(default_factory=list)
