from __future__ import annotations

import datetime as dt
import logging
import os
import pwd
import shutil
import tempfile
import time
import uuid as uuid_module
from pathlib import Path
from typing import Callable

from .command import CommandRunner, output_excerpt
from .importer import InspectedConfig, inspect_config, stage_config
from .models import (
    Credentials, ProfileDraft, ProfileRecord, Protocol, WireGuardConfig, WireGuardPeer,
)
from .secrets import password_file
from .settings import xdg_path
from .validation import ValidationError, validate_draft, validate_profile_name


LOGGER = logging.getLogger("tunny.networkmanager")
IMPORT_DIR = xdg_path("XDG_DATA_HOME", ".local/share") / "tunny" / "profiles"


def parse_terse_line(line: str) -> list[str]:
    fields: list[str] = []
    current: list[str] = []
    escaped = False
    for char in line.rstrip("\n"):
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == ":":
            fields.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        current.append("\\")
    fields.append("".join(current))
    return fields


def _protocol_from_service(connection_type: str, service: str) -> Protocol | None:
    text = f"{connection_type} {service}".lower()
    if connection_type == "wireguard":
        return Protocol.WIREGUARD
    if "openvpn" in text:
        return Protocol.OPENVPN
    if "l2tp" in text:
        return Protocol.L2TP
    if "strongswan" in text or "ikev2" in text:
        return Protocol.IKEV2
    if "openconnect" in text:
        return Protocol.OPENCONNECT
    return None


class NetworkManager:
    def __init__(
        self,
        runner: CommandRunner,
        keyfile_installer: Callable[[str], tuple[bool, str]] | None = None,
    ) -> None:
        self.runner = runner
        self.keyfile_installer = keyfile_installer

    @property
    def available(self) -> bool:
        return shutil.which("nmcli") is not None

    def state(self) -> str:
        result = self.runner.run(["nmcli", "-t", "-f", "STATE", "general"], timeout=8)
        return result.stdout.strip().lower() if result.ok else "unavailable"

    def list_profiles(self) -> list[ProfileRecord]:
        if not self.available:
            return []
        result = self.runner.run(
            ["nmcli", "--terse", "--escape", "yes", "-f", "NAME,UUID,TYPE", "connection", "show"],
            timeout=15,
        )
        if not result.ok:
            raise RuntimeError(
                "NetworkManager could not list VPN profiles: " + output_excerpt(result)
            )
        profiles: list[ProfileRecord] = []
        for line in result.stdout.splitlines():
            fields = parse_terse_line(line)
            if len(fields) != 3 or fields[2] not in {"vpn", "wireguard"}:
                continue
            name, uuid, connection_type = fields
            service = ""
            if connection_type == "vpn":
                detail = self.runner.run(
                    ["nmcli", "-g", "vpn.service-type", "connection", "show", "uuid", uuid],
                    timeout=8,
                )
                service = detail.stdout.strip() if detail.ok else ""
            protocol = _protocol_from_service(connection_type, service)
            if protocol:
                profiles.append(
                    ProfileRecord(
                        name=name, uuid=uuid, protocol=protocol, managed_by_tunny=False
                    )
                )
        return profiles

    def active_uuids(self) -> set[str]:
        result = self.runner.run(
            ["nmcli", "--terse", "--escape", "yes", "-f", "UUID,TYPE", "connection", "show", "--active"],
            timeout=10,
        )
        if not result.ok:
            return set()
        return {
            fields[0]
            for line in result.stdout.splitlines()
            if len(fields := parse_terse_line(line)) == 2 and fields[1] in {"vpn", "wireguard"}
        }

    def profile_exists(self, uuid: str) -> bool:
        return self.runner.run(
            ["nmcli", "-g", "connection.uuid", "connection", "show", "uuid", uuid],
            timeout=8,
        ).ok

    def import_profile(self, file_path: str, name: str) -> tuple[ProfileRecord, InspectedConfig]:
        name = validate_profile_name(name)
        self._ensure_unique_name(name)
        inspected = inspect_config(file_path)
        if inspected.protocol == Protocol.WIREGUARD:
            if inspected.wireguard is None:
                raise RuntimeError("The WireGuard configuration could not be parsed.")
            profile = self._install_wireguard_config(name, inspected.wireguard)
            profile.endpoint = inspected.endpoint
            profile.expected_subnets = inspected.allowed_ips
            profile.dns_servers = inspected.dns_servers
            profile.dns_search = inspected.wireguard.dns_search
            profile.full_tunnel = any(
                route in {"0.0.0.0/0", "::/0"} for route in inspected.allowed_ips
            )
            return profile, inspected
        staged = stage_config(inspected, IMPORT_DIR)
        before = {item.uuid for item in self.list_profiles()}
        result = self.runner.run(
            [
                "nmcli", "connection", "import", "type", inspected.protocol.value,
                "file", str(staged),
            ],
            timeout=45,
        )
        if not result.ok:
            shutil.rmtree(staged.parent, ignore_errors=True)
            raise RuntimeError(f"NetworkManager could not import the profile: {output_excerpt(result)}")
        after = self.list_profiles()
        created = [item for item in after if item.uuid not in before]
        if len(created) != 1:
            raise RuntimeError("The imported NetworkManager profile could not be identified safely.")
        profile = created[0]
        rename = self.runner.run(
            ["nmcli", "connection", "modify", "uuid", profile.uuid, "connection.id", name],
            timeout=15,
        )
        if not rename.ok:
            self.delete(profile.uuid)
            raise RuntimeError(f"Imported profile could not be named: {output_excerpt(rename)}")
        profile.name = name
        profile.endpoint = inspected.endpoint
        profile.expected_subnets = inspected.allowed_ips
        profile.dns_servers = inspected.dns_servers
        profile.full_tunnel = any(route in {"0.0.0.0/0", "::/0"} for route in inspected.allowed_ips)
        profile.managed_by_tunny = True
        profile.created_at = dt.datetime.now(dt.timezone.utc).isoformat()
        return profile, inspected

    def create_profile(self, draft: ProfileDraft) -> ProfileRecord:
        draft = validate_draft(draft)
        self._ensure_unique_name(draft.name)
        if draft.protocol == Protocol.WIREGUARD:
            uuid = self._create_wireguard(draft)
        else:
            uuid = self._create_vpn_plugin(draft)
        try:
            self._apply_common_settings(uuid, draft)
        except Exception:
            self.delete(uuid)
            raise
        return ProfileRecord(
            name=draft.name,
            uuid=uuid,
            protocol=draft.protocol,
            endpoint=draft.endpoint,
            expected_subnets=draft.allowed_ips,
            dns_servers=draft.dns_servers,
            dns_search=draft.dns_search,
            test_host=draft.test_host,
            test_port=draft.test_port,
            full_tunnel=draft.full_tunnel,
            managed_by_tunny=True,
            created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
        )

    def _create_wireguard(self, draft: ProfileDraft) -> str:
        config = WireGuardConfig(
            private_key=draft.private_key,
            addresses=draft.interface_addresses,
            peers=[
                WireGuardPeer(
                    public_key=draft.public_key,
                    allowed_ips=draft.allowed_ips,
                    endpoint=draft.endpoint,
                    port=draft.port or 51820,
                    preshared_key=draft.preshared_key,
                    persistent_keepalive=draft.persistent_keepalive,
                )
            ],
            dns_servers=draft.dns_servers,
            dns_search=draft.dns_search,
            mtu=draft.mtu,
        )
        return self._install_wireguard_config(draft.name, config, draft.full_tunnel).uuid

    def _install_wireguard_config(
        self,
        name: str,
        config: WireGuardConfig,
        full_tunnel: bool | None = None,
    ) -> ProfileRecord:
        if self.keyfile_installer is None:
            raise RuntimeError("The privileged WireGuard profile installer is unavailable.")
        profile_uuid = str(uuid_module.uuid4())
        if full_tunnel is None:
            full_tunnel = any(
                route in {"0.0.0.0/0", "::/0"}
                for peer in config.peers for route in peer.allowed_ips
            )
        content = self._wireguard_keyfile(name, profile_uuid, config, full_tunnel)
        fd, path = tempfile.mkstemp(prefix="tunny-keyfile-", suffix=".nmconnection")
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            ok, detail = self.keyfile_installer(path)
            if not ok:
                raise RuntimeError(f"WireGuard profile installation failed: {detail}")
        finally:
            try:
                with open(path, "r+b", buffering=0) as handle:
                    size = os.fstat(handle.fileno()).st_size
                    if size:
                        handle.write(b"\0" * size)
                        handle.flush()
                        os.fsync(handle.fileno())
            except OSError:
                pass
            try:
                os.unlink(path)
            except FileNotFoundError:
                pass
        self.reload()
        if not self.profile_exists(profile_uuid):
            raise RuntimeError("NetworkManager did not load the installed WireGuard profile.")
        endpoints = [peer.endpoint for peer in config.peers if peer.endpoint]
        routes = [route for peer in config.peers for route in peer.allowed_ips]
        return ProfileRecord(
            name=name,
            uuid=profile_uuid,
            protocol=Protocol.WIREGUARD,
            endpoint=endpoints[0] if endpoints else "",
            expected_subnets=list(dict.fromkeys(routes)),
            dns_servers=config.dns_servers,
            dns_search=config.dns_search,
            full_tunnel=full_tunnel,
            managed_by_tunny=True,
            created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
        )

    @staticmethod
    def _wireguard_keyfile(
        name: str,
        profile_uuid: str,
        config: WireGuardConfig,
        full_tunnel: bool,
    ) -> str:
        interface_name = "tn" + profile_uuid.replace("-", "")[:10]
        username = pwd.getpwuid(os.getuid()).pw_name
        if any(char in username for char in ":;\n\r"):
            raise RuntimeError("The current Linux username cannot be encoded safely in a VPN profile.")
        permissions = f"permissions=user:{username}:;"
        lines = [
            "[connection]",
            f"id={name}",
            f"uuid={profile_uuid}",
            "type=wireguard",
            f"interface-name={interface_name}",
            "autoconnect=false",
            f"timestamp={int(time.time())}",
        ]
        lines.append(permissions)
        lines.extend(["", "[wireguard]", f"private-key={config.private_key}"])
        if config.listen_port:
            lines.append(f"listen-port={config.listen_port}")
        if config.mtu:
            lines.append(f"mtu={config.mtu}")
        lines.append("peer-routes=true")
        for peer in config.peers:
            lines.extend(["", f"[wireguard-peer.{peer.public_key}]"])
            if peer.endpoint:
                endpoint = peer.endpoint
                if ":" in endpoint and not endpoint.startswith("["):
                    endpoint = f"[{endpoint}]"
                lines.append(f"endpoint={endpoint}:{peer.port or 51820}")
            lines.append("allowed-ips=" + ";".join(peer.allowed_ips) + ";")
            if peer.persistent_keepalive:
                lines.append(f"persistent-keepalive={peer.persistent_keepalive}")
            if peer.preshared_key:
                lines.append(f"preshared-key={peer.preshared_key}")

        v4_addresses = [item for item in config.addresses if ":" not in item]
        v6_addresses = [item for item in config.addresses if ":" in item]
        v4_dns = [item for item in config.dns_servers if ":" not in item]
        v6_dns = [item for item in config.dns_servers if ":" in item]
        lines.extend(["", "[ipv4]"])
        if v4_addresses:
            lines.append("method=manual")
            for index, address in enumerate(v4_addresses, start=1):
                lines.append(f"address{index}={address}")
        else:
            lines.append("method=disabled")
        lines.append(f"never-default={'false' if full_tunnel else 'true'}")
        if v4_dns:
            lines.append("dns=" + ";".join(v4_dns) + ";")
            lines.append("ignore-auto-dns=true")
        if config.dns_search:
            lines.append(f"dns-search=~{config.dns_search};")

        lines.extend(["", "[ipv6]"])
        if v6_addresses:
            lines.append("method=manual")
            for index, address in enumerate(v6_addresses, start=1):
                lines.append(f"address{index}={address}")
            lines.append(f"never-default={'false' if full_tunnel else 'true'}")
            if v6_dns:
                lines.append("dns=" + ";".join(v6_dns) + ";")
                lines.append("ignore-auto-dns=true")
        else:
            lines.append("method=disabled")
        lines.extend(["", "[proxy]", "method=none", ""])
        return "\n".join(lines)

    def _create_vpn_plugin(self, draft: ProfileDraft) -> str:
        service = {
            Protocol.OPENVPN: "openvpn",
            Protocol.L2TP: "l2tp",
            Protocol.IKEV2: "strongswan",
            Protocol.OPENCONNECT: "openconnect",
        }[draft.protocol]
        data: list[str] = []
        if draft.protocol == Protocol.L2TP:
            data = [
                f"gateway={draft.endpoint}", f"user={draft.username}",
                "ipsec-enabled=yes", "password-flags=2", "ipsec-psk-flags=2",
            ]
        elif draft.protocol == Protocol.IKEV2:
            data = [
                f"address={draft.endpoint}", f"user={draft.username}",
                "method=eap", "password-flags=2",
                "virtual=yes", "encap=yes",
            ]
            remote_identity = draft.remote_identity or draft.endpoint
            data.append(f"remote-identity={remote_identity}")
            if draft.port and draft.port != 500:
                data.append(f"server-port={draft.port}")
            if draft.certificate_path:
                data.append(f"certificate={self._stage_certificate(draft.certificate_path)}")
        elif draft.protocol == Protocol.OPENCONNECT:
            scheme = "https"
            host = draft.endpoint
            if ":" in host and not host.startswith("["):
                host = f"[{host}]"
            gateway = f"{scheme}://{host}:{draft.port or 443}"
            data = [
                f"gateway={gateway}", f"user={draft.username}",
                f"protocol={draft.openconnect_protocol}", "password-flags=2",
            ]
        else:
            raise ValidationError("Manual OpenVPN setup requires importing an .ovpn file.")
        result = self.runner.run(
            [
                "nmcli", "connection", "add", "type", "vpn", "vpn-type", service,
                "con-name", draft.name, "ifname", "--", "vpn.data", ",".join(data),
            ],
            timeout=30,
        )
        if not result.ok:
            raise RuntimeError(f"VPN profile creation failed: {output_excerpt(result)}")
        uuid_result = self.runner.run(
            ["nmcli", "-g", "connection.uuid", "connection", "show", "id", draft.name],
            timeout=10,
        )
        if not uuid_result.ok or not uuid_result.stdout.strip():
            raise RuntimeError("NetworkManager created the profile but did not return its UUID.")
        return uuid_result.stdout.strip().splitlines()[0]

    @staticmethod
    def _stage_certificate(source_value: str) -> str:
        source = Path(source_value).expanduser().resolve()
        directory = IMPORT_DIR / "certificates"
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(directory, 0o700)
        suffix = source.suffix.lower() if source.suffix.lower() in {".pem", ".crt", ".cer"} else ".crt"
        destination = directory / f"ca-{uuid_module.uuid4().hex}{suffix}"
        shutil.copyfile(source, destination)
        os.chmod(destination, 0o600)
        return str(destination)

    def _apply_common_settings(self, uuid: str, draft: ProfileDraft) -> None:
        never_default = "no" if draft.full_tunnel else "yes"
        args = [
            "nmcli", "connection", "modify", "uuid", uuid,
            "connection.autoconnect", "no",
            "ipv4.never-default", never_default,
        ]
        if draft.allowed_ips and not draft.full_tunnel and draft.protocol != Protocol.WIREGUARD:
            args.extend(["ipv4.routes", ",".join(draft.allowed_ips)])
        if draft.dns_servers:
            args.extend(["ipv4.ignore-auto-dns", "yes", "ipv4.dns", ",".join(draft.dns_servers)])
        if draft.dns_search:
            args.extend(["ipv4.dns-search", f"~{draft.dns_search}"])
        result = self.runner.run(args, timeout=20)
        if not result.ok:
            raise RuntimeError(f"VPN routes or DNS could not be configured: {output_excerpt(result)}")
        # Disabled IPv6 systems are common. This is deliberately best-effort.
        if draft.protocol != Protocol.WIREGUARD and not any(":" in route for route in draft.allowed_ips):
            self.runner.run(
                ["nmcli", "connection", "modify", "uuid", uuid, "ipv6.method", "disabled"],
                timeout=10,
            )

    def connect(self, profile: ProfileRecord, credentials: Credentials) -> tuple[bool, str]:
        with password_file(profile.protocol, credentials) as secrets_path:
            args = ["nmcli", "connection", "up", "uuid", profile.uuid]
            if secrets_path:
                args.extend(["passwd-file", secrets_path])
            result = self.runner.run(args, timeout=75)
        if result.ok:
            return True, result.stdout.strip() or "VPN connected."
        return False, output_excerpt(result, 1200)

    def disconnect(self, uuid: str) -> tuple[bool, str]:
        result = self.runner.run(
            ["nmcli", "connection", "down", "uuid", uuid], timeout=30
        )
        return result.ok, result.stdout.strip() if result.ok else output_excerpt(result)

    def delete(self, uuid: str) -> bool:
        return self.runner.run(
            ["nmcli", "connection", "delete", "uuid", uuid], timeout=20
        ).ok

    def reload(self) -> bool:
        return self.runner.run(["nmcli", "connection", "reload"], timeout=15).ok

    def modify(self, uuid: str, properties: list[str]) -> tuple[bool, str]:
        result = self.runner.run(
            ["nmcli", "connection", "modify", "uuid", uuid, *properties], timeout=20
        )
        return result.ok, output_excerpt(result)

    def connection_details(self, uuid: str) -> str:
        result = self.runner.run(
            [
                "nmcli", "-f",
                "connection.id,connection.uuid,connection.type,vpn.service-type,ipv4.routes,ipv4.dns,ipv4.dns-search,ipv4.never-default,wireguard.mtu",
                "connection", "show", "uuid", uuid,
            ],
            timeout=12,
        )
        return result.stdout if result.ok else ""

    def _ensure_unique_name(self, name: str) -> None:
        result = self.runner.run(
            ["nmcli", "-g", "connection.uuid", "connection", "show", "id", name],
            timeout=8,
        )
        if result.ok and result.stdout.strip():
            raise ValidationError(f"A NetworkManager connection named '{name}' already exists.")
