from __future__ import annotations

import argparse
import configparser
import os
import pwd
import re
import stat
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

from .distro import detect_distribution, package_command, packages_for
from .models import Protocol
from .validation import (
    split_endpoint,
    validate_dns_search,
    validate_ip_list,
    validate_networks,
    validate_port,
    validate_profile_name,
    validate_wireguard_key,
)


KEYFILE_LIMIT = 256 * 1024
KEYFILE_ALLOWED: dict[str, set[str]] = {
    "connection": {"id", "uuid", "type", "interface-name", "autoconnect", "timestamp", "permissions"},
    "wireguard": {"private-key", "listen-port", "mtu", "peer-routes"},
    "ipv4": {"method", "never-default", "dns", "dns-search", "ignore-auto-dns"},
    "ipv6": {"method", "never-default", "dns", "dns-search", "ignore-auto-dns"},
    "proxy": {"method"},
}
PEER_ALLOWED = {"endpoint", "allowed-ips", "persistent-keepalive", "preshared-key"}


def _run(args: list[str], timeout: int = 900) -> None:
    print("+ " + " ".join(args), flush=True)
    try:
        completed = subprocess.run(args, check=False, timeout=timeout, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"Timed out while running {args[0]}.") from exc
    if completed.returncode != 0:
        raise RuntimeError(f"{args[0]} exited with status {completed.returncode}.")


def install(protocol: Protocol) -> None:
    distro = detect_distribution()
    packages = packages_for(distro, protocol)
    if distro.family == "arch" and Path("/var/lib/pacman/db.lck").exists():
        raise RuntimeError(
            "pacman is already running. Finish the other package operation and try again."
        )
    os.environ.update(
        {
            "LC_ALL": "C", "LANG": "C",
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "DEBIAN_FRONTEND": "noninteractive",
        }
    )
    for command in package_command(distro, packages):
        _run(command)
    if Path("/usr/bin/systemctl").exists():
        state = subprocess.run(
            ["systemctl", "is-active", "NetworkManager"],
            check=False, capture_output=True, text=True,
        )
        if state.returncode != 0:
            _run(["systemctl", "enable", "--now", "NetworkManager"], timeout=60)
    if Path("/usr/bin/nmcli").exists():
        subprocess.run(["nmcli", "general", "reload"], check=False, timeout=20)


def start_networkmanager() -> None:
    _run(["systemctl", "enable", "--now", "NetworkManager"], timeout=60)


def _caller_uid() -> int:
    value = os.environ.get("PKEXEC_UID") or os.environ.get("SUDO_UID") or "0"
    if not value.isdigit():
        raise RuntimeError("The calling user could not be identified safely.")
    return int(value)


def _validated_keyfile(source: str) -> tuple[bytes, str]:
    if not os.path.isabs(source):
        raise RuntimeError("WireGuard keyfile source must be an absolute path.")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(source, flags)
    try:
        info = os.fstat(fd)
        caller = _caller_uid()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise RuntimeError("WireGuard keyfile must be a single regular file.")
        if info.st_uid != caller:
            raise RuntimeError("WireGuard keyfile is not owned by the calling user.")
        if info.st_mode & 0o077:
            raise RuntimeError("WireGuard keyfile must have mode 0600.")
        if info.st_size <= 0 or info.st_size > KEYFILE_LIMIT:
            raise RuntimeError("WireGuard keyfile size is outside the safety limit.")
        chunks: list[bytes] = []
        remaining = KEYFILE_LIMIT + 1
        while remaining:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b"".join(chunks)
    finally:
        os.close(fd)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise RuntimeError("WireGuard keyfile is not UTF-8 text.") from exc
    parser = configparser.ConfigParser(
        interpolation=None,
        delimiters=("=",),
        comment_prefixes=("#",),
        inline_comment_prefixes=None,
        strict=True,
        empty_lines_in_values=False,
    )
    parser.optionxform = str.lower
    try:
        parser.read_string(text)
    except configparser.Error as exc:
        raise RuntimeError(f"Invalid WireGuard keyfile: {exc}") from exc
    required = {"connection", "wireguard", "ipv4", "ipv6"}
    if not required.issubset(parser.sections()):
        raise RuntimeError("WireGuard keyfile is missing required sections.")
    for section in parser.sections():
        if section.startswith("wireguard-peer."):
            public_key = section.removeprefix("wireguard-peer.")
            validate_wireguard_key(public_key, "Peer public key")
            allowed = PEER_ALLOWED
        else:
            allowed = KEYFILE_ALLOWED.get(section)
            if allowed is None:
                raise RuntimeError(f"WireGuard keyfile contains blocked section [{section}].")
        extra = set(parser[section]) - allowed
        if section in {"ipv4", "ipv6"}:
            extra = {key for key in extra if not re.fullmatch(r"address\d+", key)}
        if extra:
            raise RuntimeError(
                f"WireGuard keyfile contains blocked properties in [{section}]: {', '.join(sorted(extra))}"
            )
    connection = parser["connection"]
    if connection.get("type") != "wireguard":
        raise RuntimeError("Only a WireGuard NetworkManager keyfile is accepted.")
    validate_profile_name(connection.get("id", ""))
    if connection.get("autoconnect", "").lower() != "false":
        raise RuntimeError("Tunneler WireGuard keyfiles must disable automatic connection.")
    if not re.fullmatch(r"tn[0-9a-f]{10}", connection.get("interface-name", "")):
        raise RuntimeError("WireGuard interface name is outside Tunneler's allowed format.")
    caller_name = pwd.getpwuid(_caller_uid()).pw_name
    if connection.get("permissions") != f"user:{caller_name}:;":
        raise RuntimeError("WireGuard keyfile permissions do not match the calling user.")
    try:
        profile_uuid = str(uuid.UUID(connection.get("uuid", "")))
    except ValueError as exc:
        raise RuntimeError("WireGuard keyfile UUID is invalid.") from exc
    wireguard = parser["wireguard"]
    validate_wireguard_key(wireguard.get("private-key", ""), "Private key")
    if wireguard.get("peer-routes", "").lower() != "true":
        raise RuntimeError("WireGuard peer route handling must be enabled.")
    if wireguard.get("listen-port"):
        validate_port(wireguard["listen-port"])
    if wireguard.get("mtu"):
        if not wireguard["mtu"].isdigit() or not 576 <= int(wireguard["mtu"]) <= 9000:
            raise RuntimeError("WireGuard MTU is outside the allowed range.")
    if not any(section.startswith("wireguard-peer.") for section in parser.sections()):
        raise RuntimeError("WireGuard keyfile has no peer sections.")
    for section in parser.sections():
        if not section.startswith("wireguard-peer."):
            continue
        peer = parser[section]
        allowed_ips = [item for item in peer.get("allowed-ips", "").split(";") if item]
        if not validate_networks(allowed_ips):
            raise RuntimeError(f"WireGuard peer [{section}] has no allowed IPs.")
        if peer.get("endpoint"):
            split_endpoint(peer["endpoint"], 51820)
        if peer.get("persistent-keepalive"):
            value = peer["persistent-keepalive"]
            if not value.isdigit() or not 0 <= int(value) <= 65535:
                raise RuntimeError("WireGuard persistent keepalive is outside the allowed range.")
        if peer.get("preshared-key"):
            validate_wireguard_key(peer["preshared-key"], "Preshared key")

    for family in ("ipv4", "ipv6"):
        ip_section = parser[family]
        if ip_section.get("method") not in {"manual", "disabled"}:
            raise RuntimeError(f"[{family}] method must be manual or disabled.")
        if ip_section.get("never-default", "true").lower() not in {"true", "false"}:
            raise RuntimeError(f"[{family}] never-default must be true or false.")
        if ip_section.get("ignore-auto-dns", "true").lower() not in {"true", "false"}:
            raise RuntimeError(f"[{family}] ignore-auto-dns must be true or false.")
        addresses = [value for key, value in ip_section.items() if re.fullmatch(r"address\d+", key)]
        if addresses:
            parsed_addresses = validate_networks(addresses, addresses=True)
            if any((":" in item) != (family == "ipv6") for item in parsed_addresses):
                raise RuntimeError(f"[{family}] contains an address from the wrong IP family.")
        dns_values = [item for item in ip_section.get("dns", "").split(";") if item]
        if dns_values:
            parsed_dns = validate_ip_list(dns_values)
            if any((":" in item) != (family == "ipv6") for item in parsed_dns):
                raise RuntimeError(f"[{family}] contains a DNS server from the wrong IP family.")
        searches = [item for item in ip_section.get("dns-search", "").split(";") if item]
        for search in searches:
            validate_dns_search(search)
    if parser.has_section("proxy") and parser["proxy"].get("method") != "none":
        raise RuntimeError("Tunneler WireGuard keyfiles cannot configure a proxy.")
    return data, profile_uuid


def install_keyfile(source: str) -> None:
    data, profile_uuid = _validated_keyfile(source)
    directory = Path("/etc/NetworkManager/system-connections")
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    destination = directory / f"tunny-{profile_uuid}.nmconnection"
    if destination.exists():
        raise RuntimeError("A NetworkManager profile with this UUID already exists.")
    fd, temporary = tempfile.mkstemp(prefix=".tunny-", dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
        result = subprocess.run(
            ["nmcli", "connection", "load", str(destination)],
            check=False, capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            destination.unlink(missing_ok=True)
            raise RuntimeError(result.stderr.strip() or "NetworkManager rejected the WireGuard keyfile.")
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="tunneler privileged helper")
    sub = parser.add_subparsers(dest="operation", required=True)
    install_parser = sub.add_parser("install")
    install_parser.add_argument("protocol", choices=[item.value for item in Protocol])
    sub.add_parser("start-networkmanager")
    keyfile_parser = sub.add_parser("install-keyfile")
    keyfile_parser.add_argument("path")
    args = parser.parse_args(argv)
    if os.geteuid() != 0:
        print("This helper must be launched through pkexec.", file=sys.stderr)
        return 77
    try:
        if args.operation == "install":
            install(Protocol(args.protocol))
        elif args.operation == "start-networkmanager":
            start_networkmanager()
        elif args.operation == "install-keyfile":
            install_keyfile(args.path)
        else:
            return 64
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print("Tunneler privileged operation completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
