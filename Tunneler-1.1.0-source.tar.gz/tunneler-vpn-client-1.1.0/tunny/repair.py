from __future__ import annotations

from .models import CheckResult, Credentials, ProfileRecord, Protocol
from .networkmanager import NetworkManager


class RepairEngine:
    """Applies only reversible profile-level repairs without changing firewall policy."""

    def __init__(self, network_manager: NetworkManager) -> None:
        self.nm = network_manager

    def apply_safe(
        self,
        profile: ProfileRecord,
        credentials: Credentials,
        checks: list[CheckResult],
    ) -> list[str]:
        codes = {item.code for item in checks}
        repaired: list[str] = []
        changed = False

        if "dns_fail" in codes and profile.dns_servers:
            properties = [
                "ipv4.ignore-auto-dns", "yes",
                "ipv4.dns", ",".join(profile.dns_servers),
            ]
            if profile.dns_search:
                properties.extend(["ipv4.dns-search", f"~{profile.dns_search}"])
            ok, _ = self.nm.modify(profile.uuid, properties)
            if ok:
                changed = True
                repaired.append("Reapplied the profile's DNS servers and split-DNS domain.")

        if "route_missing" in codes and profile.expected_subnets and profile.protocol != Protocol.WIREGUARD:
            routes = [item for item in profile.expected_subnets if item not in {"0.0.0.0/0", "::/0"}]
            if routes:
                ok, _ = self.nm.modify(profile.uuid, ["ipv4.routes", ",".join(routes)])
                if ok:
                    changed = True
                    repaired.append("Restored the expected private-network routes.")

        if "mtu_suspected" in codes and profile.protocol == Protocol.WIREGUARD:
            ok, _ = self.nm.modify(profile.uuid, ["wireguard.mtu", "1380"])
            if ok:
                changed = True
                repaired.append("Reduced the WireGuard MTU to 1380.")

        if changed:
            self.nm.disconnect(profile.uuid)
            self.nm.reload()
            connected, _ = self.nm.connect(profile, credentials)
            if connected:
                repaired.append("Reloaded and reconnected the repaired profile.")
        elif "inactive" in codes:
            self.nm.reload()
            connected, _ = self.nm.connect(profile, credentials)
            if connected:
                repaired.append("Reloaded NetworkManager profiles and reconnected the VPN.")
        return repaired

