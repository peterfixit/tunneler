from __future__ import annotations

import os
import shutil
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager

from .command import CommandRunner
from .models import Credentials, Protocol


def _validate_secret(value: str, label: str) -> str:
    if "\n" in value or "\r" in value or "\x00" in value:
        raise ValueError(f"{label} cannot contain line breaks or null bytes.")
    return value


def secret_lines(protocol: Protocol, credentials: Credentials) -> list[str]:
    lines: list[str] = []
    password = _validate_secret(credentials.password, "Password")
    psk = _validate_secret(credentials.ipsec_psk, "IPsec preshared key")
    cert_password = _validate_secret(credentials.cert_password, "Certificate password")
    if password:
        lines.append(f"vpn.secrets.password:{password}")
    if protocol == Protocol.L2TP and psk:
        lines.append(f"vpn.secrets.ipsec-psk:{psk}")
    if cert_password:
        lines.append(f"vpn.secrets.cert-pass:{cert_password}")
    return lines


@contextmanager
def password_file(protocol: Protocol, credentials: Credentials) -> Iterator[str | None]:
    lines = secret_lines(protocol, credentials)
    if not lines:
        yield None
        return
    fd, path = tempfile.mkstemp(prefix="tunny-secrets-", suffix=".txt")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        yield path
    finally:
        try:
            with open(path, "r+b", buffering=0) as handle:
                size = os.fstat(handle.fileno()).st_size
                if size:
                    handle.write(b"\0" * size)
                    handle.flush()
                    os.fsync(handle.fileno())
        except OSError:
            pass
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


class DesktopKeyring:
    """Optional Secret Service integration; secrets never enter command arguments."""

    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    @property
    def available(self) -> bool:
        return shutil.which("secret-tool") is not None

    def store(self, profile_uuid: str, key: str, value: str) -> bool:
        if not self.available or not value:
            return False
        _validate_secret(value, "Secret")
        result = self.runner.run(
            [
                "secret-tool", "store", "--label", "Tunneler VPN credential",
                "application", "tunny", "profile", profile_uuid, "key", key,
            ],
            input_text=value,
            timeout=30,
        )
        return result.ok

    def lookup(self, profile_uuid: str, key: str) -> str:
        if not self.available:
            return ""
        result = self.runner.run(
            [
                "secret-tool", "lookup", "application", "tunny",
                "profile", profile_uuid, "key", key,
            ],
            timeout=10,
        )
        return result.stdout.rstrip("\r\n") if result.ok else ""

    def clear_profile(self, profile_uuid: str) -> None:
        if self.available:
            self.runner.run(
                ["secret-tool", "clear", "application", "tunny", "profile", profile_uuid],
                timeout=10,
            )
