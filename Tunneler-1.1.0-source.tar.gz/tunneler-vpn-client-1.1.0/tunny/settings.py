from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .models import ProfileRecord


def xdg_path(variable: str, fallback: str) -> Path:
    return Path(os.environ.get(variable, str(Path.home() / fallback))).expanduser()


CONFIG_DIR = xdg_path("XDG_CONFIG_HOME", ".config") / "tunneler"
STATE_DIR = xdg_path("XDG_STATE_HOME", ".local/state") / "tunneler"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
LEGACY_SETTINGS_FILE = xdg_path("XDG_CONFIG_HOME", ".config") / "tunny" / "settings.json"


@dataclass
class Settings:
    profiles: list[ProfileRecord] = field(default_factory=list)
    theme: str = "dark"
    auto_repair: bool = True
    last_profile_uuid: str = ""
    last_picker_directory: str = ""
    window_geometry: str = "1080x720"
    schema_version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "theme": self.theme,
            "auto_repair": self.auto_repair,
            "last_profile_uuid": self.last_profile_uuid,
            "last_picker_directory": self.last_picker_directory,
            "window_geometry": self.window_geometry,
            "profiles": [profile.to_dict() for profile in self.profiles],
        }


class SettingsStore:
    def __init__(self, path: Path = SETTINGS_FILE, legacy_path: Path | None = None) -> None:
        self.path = path
        self.legacy_path = (
            LEGACY_SETTINGS_FILE if path == SETTINGS_FILE and legacy_path is None else legacy_path
        )

    def load(self) -> Settings:
        source = self.path
        if not source.exists() and self.legacy_path and self.legacy_path.exists():
            source = self.legacy_path
        if not source.exists():
            return Settings()
        try:
            raw = json.loads(source.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("settings root is not an object")
            profiles = []
            for item in raw.get("profiles", []):
                try:
                    profiles.append(ProfileRecord.from_dict(item))
                except (KeyError, TypeError, ValueError):
                    continue
            return Settings(
                profiles=profiles,
                theme="dark",
                auto_repair=bool(raw.get("auto_repair", True)),
                last_profile_uuid=str(raw.get("last_profile_uuid", "")),
                last_picker_directory=str(raw.get("last_picker_directory", "")),
                window_geometry=str(raw.get("window_geometry", "1080x720")),
                schema_version=int(raw.get("schema_version", 1)),
            )
        except (OSError, ValueError, json.JSONDecodeError):
            self._quarantine_broken_file(source)
            return Settings()

    def save(self, settings: Settings) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.path.parent, 0o700)
        payload = json.dumps(settings.to_dict(), indent=2, sort_keys=True) + "\n"
        fd, temp_name = tempfile.mkstemp(
            prefix="settings-", suffix=".tmp", dir=self.path.parent
        )
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            os.chmod(self.path, 0o600)
        finally:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass

    def _quarantine_broken_file(self, source: Path | None = None) -> None:
        path = source or self.path
        if not path.exists():
            return
        target = path.with_suffix(".json.broken")
        try:
            os.replace(path, target)
        except OSError:
            pass
