from __future__ import annotations

import logging
import queue
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any, Callable, Sequence

from . import APP_NAME, __version__
from .controller import TunnyController
from .filepicker import FileType, choose_file
from .importer import inspect_config
from .models import CheckResult, CheckStatus, Credentials, DiscoveryResult, ProfileDraft, ProfileRecord, Protocol
from .validation import ValidationError


LOGGER = logging.getLogger("tunny.ui")

COLORS = {
    "window": "#0A0F1D",
    "surface": "#11192A",
    "surface_alt": "#172238",
    "sidebar": "#070B15",
    "sidebar_hover": "#131C30",
    "sidebar_selected": "#25224A",
    "primary": "#7C6CFF",
    "primary_hover": "#6A59F0",
    "primary_soft": "#272449",
    "text": "#F1F4FA",
    "muted": "#98A4B9",
    "border": "#25314A",
    "success": "#45D6A2",
    "success_soft": "#12372F",
    "warning": "#F5BC60",
    "warning_soft": "#382A17",
    "danger": "#FF7088",
    "danger_soft": "#3B1D2A",
    "info": "#68ADFF",
    "info_soft": "#172D49",
    "input": "#0D1526",
}


def asset_path(name: str) -> Path:
    """Return an asset path in both source and PyInstaller builds."""
    bundle = getattr(sys, "_MEIPASS", None)
    base = Path(bundle) if bundle else Path(__file__).resolve().parent.parent
    return base / "assets" / name


class Card(tk.Frame):
    def __init__(self, parent: tk.Misc, **kwargs: Any) -> None:
        super().__init__(
            parent,
            bg=kwargs.pop("bg", COLORS["surface"]),
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            bd=0,
            **kwargs,
        )


class ActionButton(tk.Button):
    def __init__(
        self,
        parent: tk.Misc,
        text: str,
        command: Callable[[], None],
        *,
        kind: str = "primary",
        width: int = 0,
        state: str = "normal",
    ) -> None:
        palettes = {
            "primary": (COLORS["primary"], "white", COLORS["primary_hover"]),
            "secondary": (COLORS["surface"], COLORS["text"], COLORS["surface_alt"]),
            "danger": (COLORS["danger_soft"], COLORS["danger"], "#4A2432"),
            "success": (COLORS["success"], "#071811", "#59E3B2"),
            "ghost": (COLORS["surface_alt"], COLORS["muted"], COLORS["border"]),
        }
        bg, fg, active = palettes[kind]
        super().__init__(
            parent,
            text=text,
            command=command,
            width=width,
            state=state,
            bg=bg,
            fg=fg,
            activebackground=active,
            activeforeground=fg,
            disabledforeground="#667187",
            font=("Noto Sans", 10, "bold"),
            relief="flat",
            bd=0,
            padx=16,
            pady=9,
            cursor="hand2",
            highlightthickness=1 if kind == "secondary" else 0,
            highlightbackground=COLORS["border"],
        )


class ScrollPage(tk.Frame):
    def __init__(self, parent: tk.Misc) -> None:
        super().__init__(parent, bg=COLORS["window"])
        self.canvas = tk.Canvas(self, bg=COLORS["window"], highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.content = tk.Frame(self.canvas, bg=COLORS["window"])
        self.window = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.content.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._wheel, add="+")

    def _wheel(self, event: tk.Event) -> None:
        if self.winfo_ismapped():
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


class TunnyApp:
    def __init__(self, root: tk.Tk, controller: TunnyController, log_path: str) -> None:
        self.root = root
        self.controller = controller
        self.log_path = log_path
        self.profiles: list[ProfileRecord] = []
        self.active_uuids: set[str] = set()
        self.current_page = "dashboard"
        self.nav_buttons: dict[str, tk.Button] = {}
        self.page: tk.Widget | None = None
        self.busy = False
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.job_queue: queue.Queue[tuple[int, bool, Any, Callable[[Any], None], bool]] = queue.Queue()
        self.job_number = 0
        self.active_job: int | None = None
        self.job_deadline: float | None = None
        self.active_job_quiet = False
        self.closing = False
        self.discovery_results: list[DiscoveryResult] = []
        self.last_checks: list[CheckResult] = []

        self.root.title(f"{APP_NAME} — VPN made simple")
        self.root.geometry(controller.settings.window_geometry)
        self.root.minsize(940, 640)
        self.root.configure(bg=COLORS["window"])
        self.root.option_add("*Font", ("Noto Sans", 10))
        self.root.option_add("*Menu.background", COLORS["surface"])
        self.root.option_add("*Menu.foreground", COLORS["text"])
        self.root.option_add("*Menu.activeBackground", COLORS["primary"])
        self.root.option_add("*Menu.activeForeground", "white")
        self.root.option_add("*TCombobox*Listbox.background", COLORS["input"])
        self.root.option_add("*TCombobox*Listbox.foreground", COLORS["text"])
        self.root.option_add("*TCombobox*Listbox.selectBackground", COLORS["primary"])
        self._load_window_icon()
        self._style_ttk()
        self._build_shell()
        self.show_page("dashboard")
        self.root.after(150, self._drain_log_queue)
        self.root.after(100, self._drain_job_queue)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _load_window_icon(self) -> None:
        try:
            self.window_icon = tk.PhotoImage(file=str(asset_path("au.pmhs.tunneler.png")))
            self.root.iconphoto(True, self.window_icon)
        except (OSError, tk.TclError):
            LOGGER.warning("The bundled window icon could not be loaded.")

    def _style_ttk(self) -> None:
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure(
            "TEntry", fieldbackground=COLORS["input"], foreground=COLORS["text"],
            insertcolor=COLORS["text"],
            bordercolor=COLORS["border"], lightcolor=COLORS["border"],
            darkcolor=COLORS["border"], padding=8,
        )
        style.configure(
            "TCombobox", fieldbackground=COLORS["input"], foreground=COLORS["text"],
            background=COLORS["surface_alt"], bordercolor=COLORS["border"],
            arrowcolor=COLORS["muted"], arrowsize=16, padding=7,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", COLORS["input"])],
            foreground=[("readonly", COLORS["text"])],
            selectbackground=[("readonly", COLORS["input"])],
            selectforeground=[("readonly", COLORS["text"])],
        )
        style.configure(
            "TCheckbutton", background=COLORS["surface"], foreground=COLORS["text"],
            indicatorcolor=COLORS["input"], focuscolor=COLORS["surface"],
        )
        style.map(
            "TCheckbutton",
            background=[("active", COLORS["surface"])],
            foreground=[("disabled", COLORS["muted"])],
            indicatorcolor=[("selected", COLORS["primary"])],
        )
        style.configure(
            "Vertical.TScrollbar", background=COLORS["surface_alt"],
            troughcolor=COLORS["window"], bordercolor=COLORS["window"],
            arrowcolor=COLORS["muted"],
        )
        style.configure("Horizontal.TProgressbar", troughcolor=COLORS["border"], background=COLORS["primary"])

    def _build_shell(self) -> None:
        self.sidebar = tk.Frame(self.root, bg=COLORS["sidebar"], width=218)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=COLORS["sidebar"])
        brand.pack(fill="x", padx=20, pady=(25, 30))
        if hasattr(self, "window_icon"):
            self.brand_icon = self.window_icon.subsample(8, 8)
            tk.Label(
                brand, image=self.brand_icon, bg=COLORS["sidebar"], bd=0,
            ).pack(side="left")
        else:
            tk.Label(
                brand, text="◉", bg=COLORS["primary"], fg="white",
                font=("Noto Sans", 15, "bold"), width=2, height=1,
            ).pack(side="left")
        tk.Label(
            brand, text="TUNNELER", bg=COLORS["sidebar"], fg="white",
            font=("Noto Sans", 17, "bold"), padx=10,
        ).pack(side="left")

        items = [
            ("dashboard", "⌂", "Dashboard"),
            ("add", "+", "Add VPN"),
            ("discover", "⌁", "Discover"),
            ("diagnostics", "✓", "Diagnostics"),
            ("logs", "≡", "Activity log"),
            ("settings", "⚙", "Settings"),
        ]
        for key, icon, label in items:
            button = tk.Button(
                self.sidebar,
                text=f"  {icon}    {label}",
                anchor="w",
                command=lambda name=key: self.show_page(name),
                bg=COLORS["sidebar"], fg="#AAB5C9",
                activebackground=COLORS["sidebar_hover"], activeforeground="white",
                relief="flat", bd=0, padx=18, pady=12,
                font=("Noto Sans", 10, "bold"), cursor="hand2",
            )
            button.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[key] = button
        tk.Label(
            self.sidebar,
            text=f"Version {__version__}\nUses NetworkManager",
            bg=COLORS["sidebar"], fg="#69758C", justify="left",
            font=("Noto Sans", 9),
        ).pack(side="bottom", anchor="w", padx=24, pady=22)

        right = tk.Frame(self.root, bg=COLORS["window"])
        right.pack(side="left", fill="both", expand=True)
        self.header = tk.Frame(right, bg=COLORS["window"], height=74)
        self.header.pack(fill="x", padx=32)
        self.header.pack_propagate(False)
        self.header_title = tk.Label(
            self.header, text="", bg=COLORS["window"], fg=COLORS["text"],
            font=("Noto Sans", 20, "bold"),
        )
        self.header_title.pack(side="left", pady=20)
        self.status_pill = tk.Label(
            self.header, text="Ready", bg=COLORS["surface"], fg=COLORS["muted"],
            padx=12, pady=6, font=("Noto Sans", 9, "bold"),
        )
        self.status_pill.pack(side="right", pady=20)
        self.main = tk.Frame(right, bg=COLORS["window"])
        self.main.pack(fill="both", expand=True, padx=32, pady=(0, 26))

    def show_page(self, page: str) -> None:
        self.current_page = page
        for key, button in self.nav_buttons.items():
            selected = key == page
            button.configure(
                bg=COLORS["sidebar_selected"] if selected else COLORS["sidebar"],
                fg="white" if selected else "#AAB5C9",
            )
        if self.page:
            self.page.destroy()
        titles = {
            "dashboard": "Your VPNs", "add": "Add a VPN", "discover": "Discover a server",
            "diagnostics": "Connection diagnostics", "logs": "Activity log", "settings": "Settings",
        }
        self.header_title.configure(text=titles[page])
        builders = {
            "dashboard": self._dashboard_page,
            "add": self._add_page,
            "discover": self._discover_page,
            "diagnostics": self._diagnostics_page,
            "logs": self._logs_page,
            "settings": self._settings_page,
        }
        self.page = builders[page]()
        self.page.pack(fill="both", expand=True)

    def _dashboard_page(self) -> tk.Widget:
        page = ScrollPage(self.main)
        intro = Card(page.content, bg=COLORS["primary"])
        intro.pack(fill="x", pady=(0, 18))
        text = tk.Frame(intro, bg=COLORS["primary"])
        text.pack(side="left", fill="both", expand=True, padx=26, pady=24)
        tk.Label(
            text, text="Connect without the guesswork", bg=COLORS["primary"], fg="white",
            font=("Noto Sans", 17, "bold"), anchor="w",
        ).pack(fill="x")
        tk.Label(
            text, text="Install support, connect, test routes and DNS, then repair safe client-side issues.",
            bg=COLORS["primary"], fg="#E5E1FF", font=("Noto Sans", 10), anchor="w",
        ).pack(fill="x", pady=(6, 0))
        ActionButton(intro, "Add VPN", lambda: self.show_page("add"), kind="secondary").pack(
            side="right", padx=26
        )

        heading = tk.Frame(page.content, bg=COLORS["window"])
        heading.pack(fill="x", pady=(4, 10))
        tk.Label(
            heading, text="Profiles", bg=COLORS["window"], fg=COLORS["text"],
            font=("Noto Sans", 13, "bold"),
        ).pack(side="left")
        ActionButton(heading, "Refresh", self._load_dashboard, kind="ghost").pack(side="right")
        self.profile_container = tk.Frame(page.content, bg=COLORS["window"])
        self.profile_container.pack(fill="x")
        self._load_dashboard()
        return page

    def _load_dashboard(self) -> None:
        if not hasattr(self, "profile_container"):
            return
        if self.busy:
            self._render_profiles()
            return
        for child in self.profile_container.winfo_children():
            child.destroy()
        loading = Card(self.profile_container)
        loading.pack(fill="x")
        tk.Label(
            loading, text="Looking for NetworkManager VPN profiles…",
            bg=COLORS["surface"], fg=COLORS["muted"],
        ).pack(anchor="w", padx=20, pady=20)

        def job() -> tuple[list[ProfileRecord], set[str]]:
            return self.controller.list_profiles(), self.controller.nm.active_uuids()

        def done(value: tuple[list[ProfileRecord], set[str]]) -> None:
            self.profiles, self.active_uuids = value
            self._render_profiles()

        self._run_job(
            "Refreshing profiles…", job, done, quiet=True, timeout_seconds=45
        )

    def _render_profile_error(self, detail: str) -> None:
        if not hasattr(self, "profile_container") or not self.profile_container.winfo_exists():
            return
        for child in self.profile_container.winfo_children():
            child.destroy()
        card = Card(self.profile_container)
        card.pack(fill="x")
        text = tk.Frame(card, bg=COLORS["surface"])
        text.pack(side="left", fill="both", expand=True, padx=20, pady=18)
        tk.Label(
            text, text="Profiles could not be refreshed", bg=COLORS["surface"],
            fg=COLORS["danger"], font=("Noto Sans", 11, "bold"), anchor="w",
        ).pack(fill="x")
        tk.Label(
            text, text=detail, bg=COLORS["surface"], fg=COLORS["muted"],
            justify="left", anchor="w", wraplength=600,
        ).pack(fill="x", pady=(4, 0))
        ActionButton(card, "Try again", self._load_dashboard, kind="secondary").pack(
            side="right", padx=18
        )

    def _render_profiles(self) -> None:
        for child in self.profile_container.winfo_children():
            child.destroy()
        if not self.profiles:
            empty = Card(self.profile_container)
            empty.pack(fill="x")
            tk.Label(
                empty, text="No VPN profiles yet", bg=COLORS["surface"], fg=COLORS["text"],
                font=("Noto Sans", 13, "bold"),
            ).pack(pady=(30, 6))
            tk.Label(
                empty, text="Import a configuration, create one manually, or try server discovery.",
                bg=COLORS["surface"], fg=COLORS["muted"],
            ).pack(pady=(0, 14))
            ActionButton(empty, "Add your first VPN", lambda: self.show_page("add")).pack(pady=(0, 30))
            return
        for profile in self.profiles:
            active = profile.uuid in self.active_uuids
            card = Card(self.profile_container)
            card.pack(fill="x", pady=6)
            badge = tk.Label(
                card, text=profile.protocol.label[:2].upper(),
                bg=COLORS["primary_soft"], fg=COLORS["primary"],
                font=("Noto Sans", 11, "bold"), width=4, height=2,
            )
            badge.pack(side="left", padx=(18, 14), pady=16)
            details = tk.Frame(card, bg=COLORS["surface"])
            details.pack(side="left", fill="both", expand=True, pady=15)
            tk.Label(
                details, text=profile.name, bg=COLORS["surface"], fg=COLORS["text"],
                font=("Noto Sans", 12, "bold"), anchor="w",
            ).pack(fill="x")
            subtitle = profile.protocol.label
            if profile.endpoint:
                subtitle += f"  •  {profile.endpoint}"
            tk.Label(
                details, text=subtitle, bg=COLORS["surface"], fg=COLORS["muted"], anchor="w",
            ).pack(fill="x", pady=(4, 0))
            tk.Label(
                card, text="●  Connected" if active else "○  Disconnected",
                bg=COLORS["success_soft"] if active else COLORS["surface_alt"],
                fg=COLORS["success"] if active else COLORS["muted"],
                font=("Noto Sans", 9, "bold"), padx=10, pady=6,
            ).pack(side="left", padx=8)
            if active:
                ActionButton(
                    card, "Disconnect", lambda p=profile: self._disconnect(p), kind="secondary"
                ).pack(side="left", padx=5)
            else:
                ActionButton(
                    card, "Connect", lambda p=profile: self._credential_dialog(p), kind="success"
                ).pack(side="left", padx=5)
            ActionButton(
                card, "Test", lambda p=profile: self._run_diagnostics(p), kind="ghost"
            ).pack(side="left", padx=5)
            menu = tk.Menubutton(
                card, text="⋮", bg=COLORS["surface"], fg=COLORS["muted"],
                activebackground=COLORS["surface_alt"], activeforeground=COLORS["text"],
                relief="flat", font=("Noto Sans", 16), cursor="hand2", padx=10,
            )
            popup = tk.Menu(menu, tearoff=False)
            popup.add_command(label="Delete profile", command=lambda p=profile: self._delete_profile(p))
            menu.configure(menu=popup)
            menu.pack(side="right", padx=(2, 12))

    def _credential_dialog(self, profile: ProfileRecord) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Connect to {profile.name}")
        dialog.geometry("470x460")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(bg=COLORS["window"])
        tk.Label(
            dialog, text=f"Connect to {profile.name}", bg=COLORS["window"], fg=COLORS["text"],
            font=("Noto Sans", 17, "bold"),
        ).pack(anchor="w", padx=28, pady=(26, 4))
        tk.Label(
            dialog, text="Credentials stay in memory unless you choose the desktop keyring.",
            bg=COLORS["window"], fg=COLORS["muted"], wraplength=410, justify="left",
        ).pack(anchor="w", padx=28, pady=(0, 18))
        form = Card(dialog)
        form.pack(fill="x", padx=28)
        saved = self.controller.saved_credentials(profile)
        entries: dict[str, ttk.Entry] = {}

        def add_secret(key: str, label: str, initial: str = "") -> None:
            tk.Label(form, text=label, bg=COLORS["surface"], fg=COLORS["text"], anchor="w").pack(
                fill="x", padx=18, pady=(13, 4)
            )
            entry = ttk.Entry(form, show="•")
            entry.pack(fill="x", padx=18)
            if initial:
                entry.insert(0, initial)
            entries[key] = entry

        if profile.protocol != Protocol.WIREGUARD:
            add_secret("password", "Password", saved.password)
        if profile.protocol == Protocol.L2TP:
            add_secret("psk", "IPsec preshared key", saved.ipsec_psk)
        if profile.protocol == Protocol.OPENVPN:
            add_secret("cert", "Certificate password (only if required)", saved.cert_password)
        remember = tk.BooleanVar(value=False)
        keyring_available = self.controller.keyring.available
        ttk.Checkbutton(
            form,
            text="Remember in desktop keyring" if keyring_available else "Desktop keyring unavailable",
            variable=remember,
            state="normal" if keyring_available else "disabled",
        ).pack(anchor="w", padx=16, pady=16)
        buttons = tk.Frame(dialog, bg=COLORS["window"])
        buttons.pack(fill="x", padx=28, pady=22)
        ActionButton(buttons, "Cancel", dialog.destroy, kind="secondary").pack(side="right", padx=(8, 0))

        def connect() -> None:
            credentials = Credentials(
                password=entries.get("password").get() if entries.get("password") else "",
                ipsec_psk=entries.get("psk").get() if entries.get("psk") else "",
                cert_password=entries.get("cert").get() if entries.get("cert") else "",
            )
            dialog.destroy()
            self._connect(profile, credentials, remember.get())

        ActionButton(buttons, "Connect and test", connect, kind="success").pack(side="right")
        if entries:
            next(iter(entries.values())).focus_set()

    def _connect(
        self,
        profile: ProfileRecord,
        credentials: Credentials,
        remember: bool,
        *,
        support_checked: bool = False,
    ) -> None:
        if not support_checked:
            supported, detail = self.controller.support_status(profile.protocol)
            if not supported:
                if not messagebox.askyesno(
                    "VPN support is missing",
                    f"{detail}\n\nInstall {profile.protocol.label} support now?",
                ):
                    return

                def installed(value):
                    ok, install_detail = value
                    if not ok:
                        messagebox.showerror("Installation failed", install_detail)
                        return
                    self._connect(profile, credentials, remember, support_checked=True)

                self._run_job(
                    f"Installing {profile.protocol.label} support…",
                    lambda: self.controller.install_support(profile.protocol),
                    installed,
                )
                return

        def job():
            return self.controller.connect_and_test(profile, credentials, remember=remember)

        def done(outcome):
            self.last_checks = outcome.checks
            if outcome.connected:
                repairs = f"\n\nRepairs applied:\n• " + "\n• ".join(outcome.repaired) if outcome.repaired else ""
                messagebox.showinfo("VPN connected", f"{profile.name} is connected and tested.{repairs}")
            else:
                messagebox.showerror(
                    "VPN connection failed",
                    outcome.message + "\n\nOpen Diagnostics for the detailed checks.",
                )
            self.show_page("diagnostics")

        self._run_job(f"Connecting to {profile.name}…", job, done)

    def _disconnect(self, profile: ProfileRecord) -> None:
        def done(value):
            ok, message = value
            if not ok:
                messagebox.showerror("Could not disconnect", message)
            self.show_page("dashboard")

        self._run_job(f"Disconnecting {profile.name}…", lambda: self.controller.nm.disconnect(profile.uuid), done)

    def _delete_profile(self, profile: ProfileRecord) -> None:
        if not messagebox.askyesno(
            "Delete VPN profile",
            f"Delete '{profile.name}' from NetworkManager?\n\nThis cannot be undone, but the original imported file is not deleted.",
        ):
            return

        def done(value):
            ok, detail = value
            if not ok:
                messagebox.showerror("Delete failed", detail)
            self.show_page("dashboard")

        self._run_job("Deleting VPN profile…", lambda: self.controller.delete_profile(profile), done)

    def _add_page(self) -> tk.Widget:
        page = ScrollPage(self.main)
        tabs = tk.Frame(page.content, bg=COLORS["window"])
        tabs.pack(fill="x", pady=(0, 14))
        initial_mode = "manual" if hasattr(self, "discovery_prefill") else "import"
        self.add_mode = tk.StringVar(value=initial_mode)
        body = tk.Frame(page.content, bg=COLORS["window"])
        body.pack(fill="x")

        def select(mode: str) -> None:
            self.add_mode.set(mode)
            for child in body.winfo_children():
                child.destroy()
            if mode == "import":
                self._render_import_form(body)
            else:
                self._render_manual_form(body)

        ActionButton(tabs, "Import config", lambda: select("import"), kind="primary").pack(side="left", padx=(0, 8))
        ActionButton(tabs, "Manual setup", lambda: select("manual"), kind="secondary").pack(side="left")
        select(initial_mode)
        return page

    def _pick_into(
        self,
        variable: tk.StringVar,
        *,
        title: str,
        filetypes: Sequence[FileType],
    ) -> None:
        initial = self.controller.settings.last_picker_directory
        if not initial:
            downloads = Path.home() / "Downloads"
            initial = str(downloads if downloads.is_dir() else Path.home())
        try:
            selected = choose_file(
                self.root,
                title=title,
                filetypes=filetypes,
                initial_directory=initial,
                colors=COLORS,
            )
        except (OSError, tk.TclError) as exc:
            LOGGER.exception("The file browser failed to open.")
            messagebox.showerror("File browser error", str(exc))
            return
        if not selected:
            return
        variable.set(selected)
        self.controller.settings.last_picker_directory = str(Path(selected).parent)
        try:
            self.controller.store.save(self.controller.settings)
        except OSError:
            LOGGER.warning("The last file browser folder could not be saved.")

    def _render_import_form(self, parent: tk.Misc) -> None:
        card = Card(parent)
        card.pack(fill="x")
        self._card_heading(
            card, "Import a trusted VPN configuration",
            "Supports WireGuard .conf and OpenVPN .ovpn. Potentially executable directives are blocked before import.",
        )
        fields = tk.Frame(card, bg=COLORS["surface"])
        fields.pack(fill="x", padx=24, pady=(0, 20))
        tk.Label(
            fields,
            text=(
                "UniFi: Network → Settings → VPN → VPN Server → WireGuard → "
                "Add Client → Download configuration"
            ),
            bg=COLORS["info_soft"], fg=COLORS["info"],
            justify="left", anchor="w", wraplength=720, padx=12, pady=10,
        ).pack(fill="x", pady=(0, 10))
        name = self._field(fields, "Profile name", "Example: Work VPN")
        file_row = tk.Frame(fields, bg=COLORS["surface"])
        file_row.pack(fill="x", pady=8)
        tk.Label(file_row, text="Configuration file", bg=COLORS["surface"], fg=COLORS["text"]).pack(anchor="w")
        path_var = tk.StringVar()
        row = tk.Frame(file_row, bg=COLORS["surface"])
        row.pack(fill="x", pady=(5, 0))
        ttk.Entry(row, textvariable=path_var).pack(side="left", fill="x", expand=True)
        ActionButton(
            row,
            "Browse",
            lambda: self._pick_into(
                path_var,
                title="Choose VPN configuration",
                filetypes=(
                    FileType("VPN configurations", ("*.conf", "*.ovpn")),
                    FileType("All files", ("*",)),
                ),
            ),
            kind="secondary",
        ).pack(side="left", padx=(8, 0))

        def submit() -> None:
            if not path_var.get():
                messagebox.showwarning("Choose a file", "Select a WireGuard or OpenVPN configuration file.")
                return
            profile_name = name.get().strip() or Path(path_var.get()).stem
            try:
                inspected = inspect_config(path_var.get())
            except Exception as exc:
                messagebox.showerror("Configuration rejected", str(exc))
                return
            supported, support_detail = self.controller.support_status(inspected.protocol)
            install_first = False
            if not supported:
                install_first = messagebox.askyesno(
                    "VPN support is missing",
                    f"{support_detail}\n\nInstall {inspected.protocol.label} support before importing?",
                )
                if not install_first:
                    return

            def done(value):
                profile, warnings = value
                extra = "\n\n" + "\n".join(warnings) if warnings else ""
                messagebox.showinfo("VPN imported", f"'{profile.name}' is ready to connect.{extra}")
                self.show_page("dashboard")

            def job():
                if install_first:
                    ok, detail = self.controller.install_support(inspected.protocol)
                    if not ok:
                        raise RuntimeError(detail)
                return self.controller.add_imported(path_var.get(), profile_name)

            self._run_job("Inspecting and importing configuration…", job, done)

        ActionButton(card, "Inspect and import", submit).pack(anchor="e", padx=24, pady=(0, 24))

    def _render_manual_form(self, parent: tk.Misc) -> None:
        card = Card(parent)
        card.pack(fill="x")
        self._card_heading(
            card, "Create a profile manually",
            "WireGuard is recommended for a new server. OpenVPN requires an exported .ovpn file.",
        )
        prefill = getattr(self, "discovery_prefill", None)
        protocol_var = tk.StringVar(
            value=prefill.protocol.value if prefill else Protocol.WIREGUARD.value
        )
        selector = tk.Frame(card, bg=COLORS["surface"])
        selector.pack(fill="x", padx=24, pady=(0, 16))
        form_holder = tk.Frame(card, bg=COLORS["surface"])
        form_holder.pack(fill="x", padx=24)

        def change_protocol(*_args: Any) -> None:
            for child in form_holder.winfo_children():
                child.destroy()
            self._manual_fields(form_holder, Protocol(protocol_var.get()), card)

        for protocol in (Protocol.WIREGUARD, Protocol.L2TP, Protocol.IKEV2, Protocol.OPENCONNECT):
            tk.Radiobutton(
                selector, text=protocol.label, value=protocol.value, variable=protocol_var,
                command=change_protocol, indicatoron=False, relief="flat",
                bg=COLORS["surface_alt"], selectcolor=COLORS["primary_soft"],
                fg=COLORS["text"], activebackground=COLORS["primary_soft"],
                padx=12, pady=9, font=("Noto Sans", 9, "bold"), cursor="hand2",
            ).pack(side="left", padx=(0, 6))
        change_protocol()

    def _manual_fields(self, holder: tk.Frame, protocol: Protocol, card: Card) -> None:
        vars_: dict[str, tk.Variable | ttk.Entry] = {}
        row1 = tk.Frame(holder, bg=COLORS["surface"])
        row1.pack(fill="x")
        vars_["name"] = self._field(row1, "Profile name", "Example: Office VPN", side="left")
        vars_["endpoint"] = self._field(row1, "Server", "vpn.example.com", side="left")
        if protocol != Protocol.WIREGUARD:
            vars_["username"] = self._field(holder, "Username", "Example: user@example.com")
        if protocol == Protocol.WIREGUARD:
            vars_["private_key"] = self._field(holder, "Client private key", "Base64 WireGuard private key", secret=True)
            vars_["public_key"] = self._field(holder, "Server public key", "Base64 WireGuard public key")
            vars_["preshared_key"] = self._field(holder, "Preshared key (optional)", "Leave blank if unused", secret=True)
            pair = tk.Frame(holder, bg=COLORS["surface"])
            pair.pack(fill="x")
            vars_["addresses"] = self._field(pair, "Client address(es)", "10.20.0.2/24", side="left")
            vars_["port"] = self._field(pair, "Server port", "51820", side="left")
        elif protocol in {Protocol.IKEV2, Protocol.OPENCONNECT}:
            examples = {Protocol.IKEV2: "500", Protocol.OPENCONNECT: "443"}
            vars_["port"] = self._field(holder, "Server port", examples[protocol])
        if protocol == Protocol.IKEV2:
            vars_["remote_identity"] = self._field(
                holder, "Server certificate identity (optional)", "Example: vpn.example.com"
            )
            certificate_frame = tk.Frame(holder, bg=COLORS["surface"])
            certificate_frame.pack(fill="x", pady=7)
            tk.Label(
                certificate_frame, text="Private CA certificate (optional)",
                bg=COLORS["surface"], fg=COLORS["text"], anchor="w",
            ).pack(fill="x")
            certificate_var = tk.StringVar()
            certificate_row = tk.Frame(certificate_frame, bg=COLORS["surface"])
            certificate_row.pack(fill="x", pady=(4, 0))
            certificate_entry = ttk.Entry(certificate_row, textvariable=certificate_var)
            certificate_entry.pack(side="left", fill="x", expand=True)
            ActionButton(
                certificate_row,
                "Browse",
                lambda: self._pick_into(
                    certificate_var,
                    title="Choose IKEv2 CA certificate",
                    filetypes=(
                        FileType("Certificates", ("*.pem", "*.crt", "*.cer")),
                        FileType("All files", ("*",)),
                    ),
                ),
                kind="secondary",
            ).pack(side="left", padx=(8, 0))
            vars_["certificate"] = certificate_entry
        if protocol == Protocol.OPENCONNECT:
            tk.Label(holder, text="Server type", bg=COLORS["surface"], fg=COLORS["text"]).pack(anchor="w", pady=(8, 4))
            oc = ttk.Combobox(
                holder, state="readonly",
                values=("Cisco AnyConnect", "Palo Alto GlobalProtect", "Juniper/Pulse", "F5", "Fortinet"),
            )
            oc.current(0)
            oc.pack(fill="x")
            vars_["oc_type"] = oc
        vars_["routes"] = self._field(
            holder, "Private networks (comma separated)", "10.20.0.0/24, 10.30.0.0/24"
        )
        network_row = tk.Frame(holder, bg=COLORS["surface"])
        network_row.pack(fill="x")
        vars_["dns"] = self._field(network_row, "VPN DNS servers", "10.20.0.1", side="left")
        vars_["dns_search"] = self._field(network_row, "DNS search domain", "internal.example", side="left")
        test_row = tk.Frame(holder, bg=COLORS["surface"])
        test_row.pack(fill="x")
        vars_["test_host"] = self._field(test_row, "Test host (optional)", "server.internal.example", side="left")
        vars_["test_port"] = self._field(test_row, "Test TCP port", "443", side="left")
        full_tunnel = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            holder, text="Route all internet traffic through this VPN", variable=full_tunnel
        ).pack(anchor="w", pady=12)
        controls = tk.Frame(holder, bg=COLORS["surface"])
        controls.pack(fill="x", pady=(6, 24))

        prefill = getattr(self, "discovery_prefill", None)
        if prefill and prefill.protocol == protocol:
            endpoint_widget = vars_.get("endpoint")
            port_widget = vars_.get("port")
            if endpoint_widget is not None:
                endpoint_widget.insert(0, prefill.endpoint)  # type: ignore[union-attr]
            if port_widget is not None:
                port_widget.insert(0, str(prefill.port))  # type: ignore[union-attr]
            delattr(self, "discovery_prefill")

        def entry(name: str) -> str:
            widget = vars_.get(name)
            return widget.get().strip() if widget is not None else ""  # type: ignore[union-attr]

        def csv(name: str) -> list[str]:
            return [item.strip() for item in entry(name).split(",") if item.strip()]

        def build_draft() -> ProfileDraft:
            oc_names = {
                "Cisco AnyConnect": "anyconnect", "Palo Alto GlobalProtect": "gp",
                "Juniper/Pulse": "pulse", "F5": "f5", "Fortinet": "fortinet",
            }
            return ProfileDraft(
                name=entry("name"), protocol=protocol, endpoint=entry("endpoint"),
                username=entry("username"), private_key=entry("private_key"),
                public_key=entry("public_key"), preshared_key=entry("preshared_key"),
                interface_addresses=csv("addresses"), allowed_ips=csv("routes"),
                dns_servers=csv("dns"), dns_search=entry("dns_search"),
                test_host=entry("test_host"),
                test_port=int(entry("test_port")) if entry("test_port") else None,
                port=int(entry("port")) if entry("port") else None,
                full_tunnel=full_tunnel.get(),
                openconnect_protocol=oc_names.get(entry("oc_type"), "anyconnect"),
                remote_identity=entry("remote_identity"),
                certificate_path=entry("certificate"),
            )

        def create() -> None:
            try:
                draft = build_draft()
            except ValueError:
                messagebox.showerror("Invalid number", "Ports must contain numbers only.")
                return

            supported, support_detail = self.controller.support_status(protocol)
            install_first = False
            if not supported:
                install_first = messagebox.askyesno(
                    "VPN support is missing",
                    f"{support_detail}\n\nInstall {protocol.label} support before creating the profile?",
                )
                if not install_first:
                    return

            def done(profile):
                messagebox.showinfo("VPN ready", f"'{profile.name}' was created. Credentials will be requested when connecting.")
                self.show_page("dashboard")

            def job():
                if install_first:
                    ok, install_detail = self.controller.install_support(protocol)
                    if not ok:
                        raise RuntimeError(install_detail)
                return self.controller.add_manual(draft)

            self._run_job("Creating VPN profile…", job, done)

        ActionButton(controls, "Install protocol support", lambda: self._install_protocol(protocol), kind="secondary").pack(side="left")
        ActionButton(controls, "Create profile", create).pack(side="right")

    def _install_protocol(self, protocol: Protocol) -> None:
        if not messagebox.askyesno(
            "Install VPN support",
            f"Install the NetworkManager packages needed for {protocol.label}?\n\nYour administrator password may be requested.",
        ):
            return

        def done(value):
            ok, detail = value
            if ok:
                messagebox.showinfo("Support installed", detail)
            else:
                messagebox.showerror("Installation failed", detail)

        self._run_job(f"Installing {protocol.label} support…", lambda: self.controller.install_support(protocol), done)

    def _discover_page(self) -> tk.Widget:
        page = ScrollPage(self.main)
        card = Card(page.content)
        card.pack(fill="x")
        self._card_heading(
            card, "Find likely VPN services",
            "Enter a known domain/address, or leave it blank to check mDNS, the gateway, and already-seen local devices. Tunneler never sweeps the entire subnet.",
        )
        content = tk.Frame(card, bg=COLORS["surface"])
        content.pack(fill="x", padx=24, pady=(0, 20))
        seed = self._field(content, "Server domain or address (optional)", "vpn.example.com")
        tk.Label(
            content,
            text="WireGuard, L2TP and IKEv2 normally use silent UDP, so remote discovery cannot prove they exist. Importing the server's config remains the reliable method.",
            bg=COLORS["warning_soft"], fg=COLORS["warning"], wraplength=720,
            justify="left", padx=12, pady=10,
        ).pack(fill="x", pady=10)
        ActionButton(content, "Discover", lambda: self._start_discovery(seed.get())).pack(anchor="e", pady=(4, 0))
        self.discovery_container = tk.Frame(page.content, bg=COLORS["window"])
        self.discovery_container.pack(fill="x", pady=(16, 0))
        self._render_discovery_results()
        return page

    def _start_discovery(self, seed: str) -> None:
        def done(results):
            self.discovery_results = results
            self._render_discovery_results()

        self._run_job("Checking for VPN services…", lambda: self.controller.discovery.discover(seed), done)

    def _render_discovery_results(self) -> None:
        if not hasattr(self, "discovery_container"):
            return
        for child in self.discovery_container.winfo_children():
            child.destroy()
        if not self.discovery_results:
            tk.Label(
                self.discovery_container,
                text="No results yet. For the most reliable setup, import a configuration exported by the VPN server.",
                bg=COLORS["window"], fg=COLORS["muted"], wraplength=700, justify="left",
            ).pack(anchor="w", pady=10)
            return
        for result in self.discovery_results:
            row = Card(self.discovery_container)
            row.pack(fill="x", pady=5)
            tk.Label(
                row, text=result.protocol.label, bg=COLORS["surface"], fg=COLORS["text"],
                font=("Noto Sans", 11, "bold"), width=20, anchor="w",
            ).pack(side="left", padx=16, pady=15)
            tk.Label(
                row, text=f"{result.endpoint}:{result.port}\n{result.source} • {result.confidence}",
                bg=COLORS["surface"], fg=COLORS["muted"], justify="left", anchor="w",
            ).pack(side="left", fill="x", expand=True)
            ActionButton(
                row, "Use", lambda item=result: self._use_discovery(item), kind="secondary"
            ).pack(side="right", padx=14)

    def _use_discovery(self, result: DiscoveryResult) -> None:
        self.discovery_prefill = result
        self.show_page("add")
        messagebox.showinfo(
            "Discovery result",
            f"The manual form has been prefilled with {result.endpoint}:{result.port}.\n\nDiscovery is a hint, not proof of a compatible VPN service.",
        )

    def _diagnostics_page(self) -> tk.Widget:
        page = ScrollPage(self.main)
        controls = Card(page.content)
        controls.pack(fill="x", pady=(0, 14))
        self._card_heading(
            controls, "Test the complete path",
            "Checks NetworkManager, profile state, endpoint DNS, routes, subnet conflicts, split DNS, services, WireGuard handshakes, and recent failure signatures.",
        )
        row = tk.Frame(controls, bg=COLORS["surface"])
        row.pack(fill="x", padx=24, pady=(0, 20))
        profiles = self.controller.list_profiles()
        self.profiles = profiles
        values = [profile.name for profile in profiles]
        combo = ttk.Combobox(row, values=values, state="readonly")
        if values:
            combo.current(0)
        combo.pack(side="left", fill="x", expand=True)
        ActionButton(
            row, "Run diagnostics",
            lambda: self._run_diagnostics(next((p for p in profiles if p.name == combo.get()), profiles[0] if profiles else None)),
        ).pack(side="left", padx=(10, 0))
        self.check_container = tk.Frame(page.content, bg=COLORS["window"])
        self.check_container.pack(fill="x")
        self._render_checks(self.last_checks)
        return page

    def _run_diagnostics(self, profile: ProfileRecord | None) -> None:
        if profile is None:
            messagebox.showwarning("No profile", "Add or import a VPN profile first.")
            return

        def done(checks):
            self.last_checks = checks
            if self.current_page != "diagnostics":
                self.show_page("diagnostics")
            else:
                self._render_checks(checks)

        self._run_job(f"Testing {profile.name}…", lambda: self.controller.diagnostics.run(profile), done)

    def _render_checks(self, checks: list[CheckResult]) -> None:
        if not hasattr(self, "check_container"):
            return
        for child in self.check_container.winfo_children():
            child.destroy()
        if not checks:
            tk.Label(
                self.check_container, text="Run diagnostics to see each check here.",
                bg=COLORS["window"], fg=COLORS["muted"],
            ).pack(anchor="w", pady=12)
            return
        palette = {
            CheckStatus.PASS: (COLORS["success"], COLORS["success_soft"], "✓"),
            CheckStatus.FIXED: (COLORS["success"], COLORS["success_soft"], "✓"),
            CheckStatus.WARN: (COLORS["warning"], COLORS["warning_soft"], "!"),
            CheckStatus.FAIL: (COLORS["danger"], COLORS["danger_soft"], "×"),
            CheckStatus.INFO: (COLORS["info"], COLORS["info_soft"], "i"),
        }
        for check in checks:
            fg, bg, icon = palette[check.status]
            card = Card(self.check_container)
            card.pack(fill="x", pady=5)
            tk.Label(
                card, text=icon, bg=bg, fg=fg, font=("Noto Sans", 13, "bold"),
                width=3, height=2,
            ).pack(side="left", padx=14, pady=12)
            text = tk.Frame(card, bg=COLORS["surface"])
            text.pack(side="left", fill="both", expand=True, pady=12, padx=(0, 14))
            tk.Label(
                text, text=check.title, bg=COLORS["surface"], fg=COLORS["text"],
                font=("Noto Sans", 10, "bold"), anchor="w",
            ).pack(fill="x")
            tk.Label(
                text, text=check.detail, bg=COLORS["surface"], fg=COLORS["muted"],
                justify="left", anchor="w", wraplength=650,
            ).pack(fill="x", pady=(3, 0))

    def _logs_page(self) -> tk.Widget:
        page = tk.Frame(self.main, bg=COLORS["window"])
        card = Card(page)
        card.pack(fill="both", expand=True)
        toolbar = tk.Frame(card, bg=COLORS["surface"])
        toolbar.pack(fill="x", padx=18, pady=14)
        tk.Label(
            toolbar, text="Secrets are automatically redacted", bg=COLORS["surface"],
            fg=COLORS["success"], font=("Noto Sans", 9, "bold"),
        ).pack(side="left")
        ActionButton(toolbar, "Refresh", self._refresh_log, kind="ghost").pack(side="right")
        self.log_text = tk.Text(
            card, bg="#080D18", fg="#C9D2E3", insertbackground="white",
            relief="flat", padx=16, pady=14, font=("DejaVu Sans Mono", 9), wrap="word",
        )
        self.log_text.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        self._refresh_log()
        return page

    def _refresh_log(self) -> None:
        if not hasattr(self, "log_text"):
            return
        try:
            content = Path(self.log_path).read_text(encoding="utf-8")[-120_000:]
        except OSError as exc:
            content = f"Log unavailable: {exc}"
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", content)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _settings_page(self) -> tk.Widget:
        page = ScrollPage(self.main)
        card = Card(page.content)
        card.pack(fill="x")
        self._card_heading(
            card, "Connection repair",
            "Tunneler only applies reversible profile-level repairs. It never changes your firewall, server, router, or remote network automatically.",
        )
        auto = tk.BooleanVar(value=self.controller.settings.auto_repair)

        def save_auto() -> None:
            self.controller.settings.auto_repair = auto.get()
            self.controller.store.save(self.controller.settings)

        ttk.Checkbutton(
            card, text="Attempt safe repairs after a failed connection test",
            variable=auto, command=save_auto,
        ).pack(anchor="w", padx=24, pady=(0, 22))
        about = Card(page.content)
        about.pack(fill="x", pady=14)
        self._card_heading(
            about, f"Tunneler {__version__}",
            "A focused Linux VPN connection assistant. WireGuard, OpenVPN, L2TP/IPsec, IKEv2 and OpenConnect are handled by NetworkManager and the distribution's maintained plugins.",
        )
        tk.Label(
            about,
            text="No telemetry • No cloud account • No external IP lookup • MIT licensed",
            bg=COLORS["surface"], fg=COLORS["muted"],
        ).pack(anchor="w", padx=24, pady=(0, 22))
        return page

    def _field(
        self, parent: tk.Misc, label: str, placeholder: str,
        *, side: str | None = None, secret: bool = False,
    ) -> ttk.Entry:
        frame = tk.Frame(parent, bg=COLORS["surface"])
        if side:
            frame.pack(side=side, fill="x", expand=True, padx=(0, 8) if side == "left" else 0, pady=7)
        else:
            frame.pack(fill="x", pady=7)
        tk.Label(frame, text=label, bg=COLORS["surface"], fg=COLORS["text"], anchor="w").pack(fill="x")
        entry = ttk.Entry(frame, show="•" if secret else "")
        entry.pack(fill="x", pady=(4, 0))
        entry.insert(0, "")
        # Tk has no portable placeholder support; a muted hint remains outside the value.
        tk.Label(
            frame, text=placeholder, bg=COLORS["surface"], fg="#6F7B91",
            anchor="w", font=("Noto Sans", 8),
        ).pack(fill="x", pady=(2, 0))
        return entry

    @staticmethod
    def _card_heading(card: tk.Frame, title: str, subtitle: str) -> None:
        tk.Label(
            card, text=title, bg=COLORS["surface"], fg=COLORS["text"],
            font=("Noto Sans", 14, "bold"), anchor="w",
        ).pack(fill="x", padx=24, pady=(22, 4))
        tk.Label(
            card, text=subtitle, bg=COLORS["surface"], fg=COLORS["muted"],
            justify="left", anchor="w", wraplength=760,
        ).pack(fill="x", padx=24, pady=(0, 18))

    def _run_job(
        self,
        label: str,
        job: Callable[[], Any],
        done: Callable[[Any], None],
        *,
        quiet: bool = False,
        timeout_seconds: float | None = None,
    ) -> None:
        if self.busy:
            if not quiet:
                messagebox.showinfo("Tunneler is busy", "Wait for the current task to finish.")
            return
        self.busy = True
        self.job_number += 1
        job_number = self.job_number
        self.active_job = job_number
        self.active_job_quiet = quiet
        self.job_deadline = (
            time.monotonic() + timeout_seconds if timeout_seconds is not None else None
        )
        self._set_status(label, "busy")

        def worker() -> None:
            try:
                value = job()
            except Exception as exc:
                LOGGER.exception("Background task failed: %s", exc)
                self.job_queue.put((job_number, False, exc, done, quiet))
            else:
                self.job_queue.put((job_number, True, value, done, quiet))

        threading.Thread(target=worker, daemon=True).start()

    def _job_done(self, value: Any, done: Callable[[Any], None]) -> None:
        self.busy = False
        self.active_job = None
        self.job_deadline = None
        self._set_status("Ready", "ready")
        try:
            done(value)
        except Exception as exc:
            LOGGER.exception("Background result handler failed: %s", exc)
            self._job_failed(exc)

    def _job_failed(self, exc: Exception, quiet: bool = False) -> None:
        self.busy = False
        self.active_job = None
        self.job_deadline = None
        self._set_status("Needs attention", "error")
        if quiet:
            self._render_profile_error(str(exc))
            return
        if isinstance(exc, (ValidationError, ValueError)):
            messagebox.showerror("Check these details", str(exc))
        else:
            messagebox.showerror(
                "Operation failed",
                f"{exc}\n\nThe full redacted detail is in Activity log.",
            )

    def _set_status(self, text: str, state: str) -> None:
        palette = {
            "ready": (COLORS["surface"], COLORS["muted"]),
            "busy": (COLORS["primary_soft"], COLORS["primary"]),
            "error": (COLORS["danger_soft"], COLORS["danger"]),
        }
        bg, fg = palette[state]
        self.status_pill.configure(text=text, bg=bg, fg=fg)

    def queue_log(self, line: str) -> None:
        self.log_queue.put(line)

    def _drain_job_queue(self) -> None:
        while True:
            try:
                number, succeeded, payload, done, quiet = self.job_queue.get_nowait()
            except queue.Empty:
                break
            if number != self.active_job:
                continue
            if succeeded:
                self._job_done(payload, done)
            else:
                self._job_failed(payload, quiet)

        if self.busy and self.job_deadline is not None and time.monotonic() >= self.job_deadline:
            quiet = self.active_job_quiet
            self.active_job = None
            self.job_deadline = None
            self.busy = False
            self._job_failed(
                TimeoutError(
                    "NetworkManager took too long to respond. Check that it is running, then try again."
                ),
                quiet,
            )
        if not self.closing:
            self.root.after(100, self._drain_job_queue)

    def _drain_log_queue(self) -> None:
        while True:
            try:
                self.log_queue.get_nowait()
            except queue.Empty:
                break
        if not self.closing:
            self.root.after(200, self._drain_log_queue)

    def _on_close(self) -> None:
        self.closing = True
        geometry = self.root.geometry()
        if geometry and geometry[0].isdigit():
            self.controller.settings.window_geometry = geometry
            self.controller.store.save(self.controller.settings)
        self.root.destroy()
