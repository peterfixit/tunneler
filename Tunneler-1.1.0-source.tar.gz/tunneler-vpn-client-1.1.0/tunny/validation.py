from __future__ import annotations

import base64
import binascii
import ipaddress
import re
from pathlib import Path
from urllib.parse import urlsplit

from .models import ProfileDraft, Protocol


HOST_RE = re.compile(
    r"^(?=.{1,253}\.?$)(?!-)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*"
    r"[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.?$"
)
PROFILE_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,80}$")
UNSAFE_VPN_DATA_CHARS = {",", "\n", "\r", "\x00"}


class ValidationError(ValueError):
    pass


def validate_profile_name(value: str) -> str:
    value = value.strip()
    if not PROFILE_RE.match(value):
        raise ValidationError("Profile name must be 1–80 printable characters.")
    return value


def validate_port(value: int | str | None, *, required: bool = False) -> int | None:
    if value in (None, ""):
        if required:
            raise ValidationError("A server port is required.")
        return None
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError("Port must be a number between 1 and 65535.") from exc
    if not 1 <= port <= 65535:
        raise ValidationError("Port must be between 1 and 65535.")
    return port


def split_endpoint(value: str, default_port: int | None = None) -> tuple[str, int | None]:
    value = value.strip()
    if not value:
        raise ValidationError("A VPN server hostname or IP address is required.")
    if any(char in value for char in "\n\r\x00"):
        raise ValidationError("Server address contains invalid characters.")

    host = value
    port = default_port
    if "://" in value:
        parsed = urlsplit(value)
        if parsed.scheme not in {"https", "http"} or not parsed.hostname:
            raise ValidationError("Only a valid HTTP or HTTPS server URL is accepted here.")
        host = parsed.hostname
        port = parsed.port or default_port
    elif value.startswith("["):
        match = re.fullmatch(r"\[([^]]+)](?::(\d+))?", value)
        if not match:
            raise ValidationError("Invalid bracketed IPv6 server address.")
        host = match.group(1)
        port = int(match.group(2)) if match.group(2) else default_port
    elif value.count(":") == 1:
        possible_host, possible_port = value.rsplit(":", 1)
        if possible_port.isdigit():
            host, port = possible_host, int(possible_port)

    validate_host(host)
    return host.rstrip("."), validate_port(port)


def validate_host(host: str) -> str:
    host = host.strip().rstrip(".")
    if not host:
        raise ValidationError("Server hostname or IP address is blank.")
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    if not HOST_RE.fullmatch(host):
        raise ValidationError("Enter a valid hostname or IP address.")
    return host


def validate_networks(values: list[str], *, addresses: bool = False) -> list[str]:
    cleaned: list[str] = []
    for raw in values:
        raw = raw.strip()
        if not raw:
            continue
        try:
            if addresses:
                cleaned.append(str(ipaddress.ip_interface(raw)))
            else:
                cleaned.append(str(ipaddress.ip_network(raw, strict=False)))
        except ValueError as exc:
            kind = "interface address" if addresses else "network route"
            raise ValidationError(f"Invalid {kind}: {raw}") from exc
    return list(dict.fromkeys(cleaned))


def validate_ip_list(values: list[str]) -> list[str]:
    cleaned: list[str] = []
    for raw in values:
        raw = raw.strip()
        if not raw:
            continue
        try:
            cleaned.append(str(ipaddress.ip_address(raw)))
        except ValueError as exc:
            raise ValidationError(f"Invalid DNS server address: {raw}") from exc
    return list(dict.fromkeys(cleaned))


def validate_wireguard_key(value: str, label: str, *, required: bool = True) -> str:
    value = value.strip()
    if not value and not required:
        return ""
    try:
        decoded = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValidationError(f"{label} is not a valid WireGuard key.") from exc
    if len(decoded) != 32:
        raise ValidationError(f"{label} must decode to exactly 32 bytes.")
    return value


def validate_vpn_data_text(value: str, label: str, *, required: bool = False) -> str:
    value = value.strip()
    if required and not value:
        raise ValidationError(f"{label} is required.")
    if any(char in value for char in UNSAFE_VPN_DATA_CHARS):
        raise ValidationError(f"{label} cannot contain commas or control characters.")
    if len(value) > 512:
        raise ValidationError(f"{label} is too long.")
    return value


def validate_dns_search(value: str) -> str:
    value = value.strip().lstrip("~").rstrip(".")
    if not value:
        return ""
    return validate_host(value)


def validate_draft(draft: ProfileDraft) -> ProfileDraft:
    draft.name = validate_profile_name(draft.name)
    default_ports = {
        Protocol.WIREGUARD: 51820,
        Protocol.L2TP: 1701,
        Protocol.IKEV2: 500,
        Protocol.OPENCONNECT: 443,
    }
    if draft.protocol != Protocol.OPENVPN:
        host, embedded_port = split_endpoint(
            draft.endpoint, draft.port or default_ports.get(draft.protocol)
        )
        draft.endpoint = host
        draft.port = embedded_port
    draft.username = validate_vpn_data_text(draft.username, "Username")
    draft.allowed_ips = validate_networks(draft.allowed_ips)
    draft.interface_addresses = validate_networks(draft.interface_addresses, addresses=True)
    draft.dns_servers = validate_ip_list(draft.dns_servers)
    draft.dns_search = validate_dns_search(draft.dns_search)
    if draft.remote_identity:
        draft.remote_identity = validate_host(draft.remote_identity)
    if draft.test_host:
        draft.test_host = validate_host(draft.test_host)
    draft.test_port = validate_port(draft.test_port)
    if draft.protocol == Protocol.WIREGUARD:
        if draft.full_tunnel and "0.0.0.0/0" not in draft.allowed_ips:
            draft.allowed_ips.append("0.0.0.0/0")
        if any(route in {"0.0.0.0/0", "::/0"} for route in draft.allowed_ips):
            draft.full_tunnel = True
        draft.private_key = validate_wireguard_key(draft.private_key, "Private key")
        draft.public_key = validate_wireguard_key(draft.public_key, "Server public key")
        draft.preshared_key = validate_wireguard_key(
            draft.preshared_key, "Preshared key", required=False
        )
        if not draft.interface_addresses:
            raise ValidationError("At least one WireGuard interface address is required.")
        if not draft.allowed_ips:
            raise ValidationError("At least one WireGuard allowed network is required.")
        if not 0 <= draft.persistent_keepalive <= 65535:
            raise ValidationError("Persistent keepalive must be between 0 and 65535 seconds.")
        if draft.mtu is not None and not 576 <= draft.mtu <= 9000:
            raise ValidationError("MTU must be between 576 and 9000.")
    if draft.protocol in {Protocol.L2TP, Protocol.IKEV2, Protocol.OPENCONNECT}:
        draft.username = validate_vpn_data_text(draft.username, "Username", required=True)
    if draft.protocol == Protocol.IKEV2 and draft.certificate_path:
        certificate = Path(draft.certificate_path).expanduser()
        if not certificate.is_file() or certificate.stat().st_size > 2 * 1024 * 1024:
            raise ValidationError("IKEv2 CA certificate is missing, invalid, or larger than 2 MiB.")
    if draft.openconnect_protocol not in {"anyconnect", "gp", "nc", "pulse", "f5", "fortinet"}:
        raise ValidationError("Unsupported OpenConnect server type.")
    return draft


def networks_overlap(local_networks: list[str], remote_networks: list[str]) -> list[tuple[str, str]]:
    overlaps: list[tuple[str, str]] = []
    for local_raw in local_networks:
        for remote_raw in remote_networks:
            try:
                local = ipaddress.ip_network(local_raw, strict=False)
                remote = ipaddress.ip_network(remote_raw, strict=False)
            except ValueError:
                continue
            if local.version == remote.version and local.overlaps(remote):
                overlaps.append((str(local), str(remote)))
    return overlaps
